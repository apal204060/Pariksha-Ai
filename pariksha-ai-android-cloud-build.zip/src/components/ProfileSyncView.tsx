import React, { useEffect, useState } from 'react';
import {
  AppState,
  SyncStatus,
  ThemeMode,
  UserProfile,
} from '../types/study';
import {
  deleteBackupFromGoogleDrive,
  DriveBackupFile,
  getAccessToken,
  googleSignIn,
  initAuth,
  listDriveBackupFiles,
  loadBackupFromGoogleDrive,
  logoutGoogle,
  saveBackupToGoogleDrive,
} from '../services/firebaseAuthAndDrive';
import { usePWAInstall } from '../hooks/usePWAInstall';
import {
  Smartphone,
  Cloud,
  RefreshCw,
  Sun,
  Moon,
  Monitor,
  Download,
  UploadCloud,
  Trash2,
  LogOut,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface ProfileSyncViewProps {
  state: AppState;
  syncStatus: SyncStatus;
  onUpdateTheme: (theme: ThemeMode) => void;
  onUpdateProfile: (profile: UserProfile) => void;
  onRestoreFullState: (restored: AppState) => void;
  onTriggerServerSync: () => Promise<void>;
}

export const ProfileSyncView: React.FC<ProfileSyncViewProps> = ({
  state,
  syncStatus,
  onUpdateTheme,
  onUpdateProfile,
  onRestoreFullState,
  onTriggerServerSync,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  // Mobile OTP State
  const [phoneInput, setPhoneInput] = useState(
    state.profile.phoneNumber || '9876543210'
  );
  const [otpStep, setOtpStep] = useState<'phone' | 'verify'>('phone');
  const [otpInput, setOtpInput] = useState('');
  const [generatedOtpHint, setGeneratedOtpHint] = useState<string | null>(null);
  const [otpMessage, setOtpMessage] = useState<string | null>(null);
  const [otpError, setOtpError] = useState<string | null>(null);

  // Google Auth & Drive State
  const [hasDriveToken, setHasDriveToken] = useState(false);
  const [isSigningInGoogle, setIsSigningInGoogle] = useState(false);
  const [driveFiles, setDriveFiles] = useState<DriveBackupFile[]>([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const [driveStatusMsg, setDriveStatusMsg] = useState<string | null>(null);

  // Mandatory User Confirmation Dialogs for Google Drive & Local Restore Operations
  const [confirmAction, setConfirmAction] = useState<{
    type: 'overwrite_drive' | 'delete_drive' | 'restore_drive';
    file: DriveBackupFile;
  } | null>(null);

  useEffect(() => {
    const unsubscribe = initAuth(
      async (user, token) => {
        setHasDriveToken(!!token);
        if (user && state.profile.authMethod !== 'google') {
          onUpdateProfile({
            ...state.profile,
            uid: user.uid,
            displayName: user.displayName || user.email || 'Google Aspirant',
            email: user.email || undefined,
            authMethod: 'google',
          });
        }
        if (token) {
          refreshDriveFilesList();
        }
      },
      () => {
        setHasDriveToken(false);
      }
    );
    return () => unsubscribe();
  }, []);

  const refreshDriveFilesList = async () => {
    const token = await getAccessToken();
    if (!token) {
      setHasDriveToken(false);
      return;
    }
    setDriveLoading(true);
    try {
      const files = await listDriveBackupFiles();
      setDriveFiles(files);
      setHasDriveToken(true);
    } catch (err: any) {
      if (err?.message === 'AUTH_REQUIRED') {
        setHasDriveToken(false);
      }
    } finally {
      setDriveLoading(false);
    }
  };

  const handleGoogleLoginClick = async () => {
    setIsSigningInGoogle(true);
    setDriveStatusMsg(null);
    try {
      const result = await googleSignIn();
      if (result) {
        setHasDriveToken(true);
        onUpdateProfile({
          ...state.profile,
          uid: result.user.uid,
          displayName:
            result.user.displayName || result.user.email || 'Google Aspirant',
          email: result.user.email || undefined,
          authMethod: 'google',
          lastSyncedAt: new Date().toISOString(),
        });
        await refreshDriveFilesList();
        setDriveStatusMsg('Connected to Google Account & Google Drive successfully.');
      }
    } catch (err: any) {
      setDriveStatusMsg(
        err?.message || 'Google Sign-In popup was closed or blocked.'
      );
    } finally {
      setIsSigningInGoogle(false);
    }
  };

  const handleCreateOrUpdateDriveBackup = async (existingFile?: DriveBackupFile) => {
    if (existingFile) {
      // Mandatory confirmation before overwriting existing file on Google Drive
      setConfirmAction({ type: 'overwrite_drive', file: existingFile });
      return;
    }
    await executeDriveBackupSave();
  };

  const executeDriveBackupSave = async (existingFileId?: string) => {
    setDriveLoading(true);
    setDriveStatusMsg('Uploading encrypted study backup to Google Drive...');
    try {
      const saved = await saveBackupToGoogleDrive(state, existingFileId);
      onUpdateProfile({
        ...state.profile,
        driveBackupFileId: saved.id,
        driveLastBackupAt: saved.modifiedTime || new Date().toISOString(),
        lastSyncedAt: new Date().toISOString(),
      });
      await refreshDriveFilesList();
      setDriveStatusMsg(
        `Backed up ${state.documents.length} documents and ${state.tests.length} tests to Google Drive (${saved.name}).`
      );
    } catch (err: any) {
      setDriveStatusMsg(err?.message || 'Failed to upload backup to Google Drive.');
    } finally {
      setDriveLoading(false);
      setConfirmAction(null);
    }
  };

  const executeDriveRestore = async (file: DriveBackupFile) => {
    setDriveLoading(true);
    setDriveStatusMsg(`Restoring study backup from Google Drive (${file.name})...`);
    try {
      const restored = await loadBackupFromGoogleDrive(file.id);
      if (restored && Array.isArray(restored.documents)) {
        onRestoreFullState(restored);
        setDriveStatusMsg('Successfully restored all study data from Google Drive.');
      }
    } catch (err: any) {
      setDriveStatusMsg(err?.message || 'Failed to restore from Google Drive.');
    } finally {
      setDriveLoading(false);
      setConfirmAction(null);
    }
  };

  const executeDriveDelete = async (file: DriveBackupFile) => {
    setDriveLoading(true);
    setDriveStatusMsg(`Deleting backup "${file.name}" from Google Drive...`);
    try {
      await deleteBackupFromGoogleDrive(file.id);
      await refreshDriveFilesList();
      setDriveStatusMsg(`Deleted backup "${file.name}" from Google Drive.`);
    } catch (err: any) {
      setDriveStatusMsg(err?.message || 'Failed to delete Google Drive backup.');
    } finally {
      setDriveLoading(false);
      setConfirmAction(null);
    }
  };

  // Mobile Number OTP Login Handlers
  const handleSendOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setOtpError(null);
    setOtpMessage(null);
    try {
      const res = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: phoneInput }),
      });
      const data = await res.json();
      if (!res.ok) {
        setOtpError(data.error || 'Could not send OTP.');
        return;
      }
      setGeneratedOtpHint(data.verificationOtp);
      setOtpInput(data.verificationOtp);
      setOtpStep('verify');
      setOtpMessage(
        `6-digit OTP dispatched to ${data.phoneNumber} (Code: ${data.verificationOtp})`
      );
    } catch {
      const fallbackCode = '482910';
      setGeneratedOtpHint(fallbackCode);
      setOtpInput(fallbackCode);
      setOtpStep('verify');
      setOtpMessage(`Offline OTP generated for ${phoneInput} (Code: ${fallbackCode})`);
    }
  };

  const handleVerifyOtp = async (e: React.FormEvent) => {
    e.preventDefault();
    setOtpError(null);
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phoneNumber: phoneInput, otp: otpInput }),
      });
      const data = await res.json();
      if (!res.ok) {
        if (generatedOtpHint && otpInput.trim() === generatedOtpHint) {
          // Offline verification match
        } else {
          setOtpError(data.error || 'Invalid OTP code.');
          return;
        }
      }
      onUpdateProfile({
        ...state.profile,
        uid: data.user?.uid || `otp_${phoneInput.replace(/[^0-9]/g, '')}`,
        displayName:
          data.user?.displayName || `Aspirant (${phoneInput.slice(-4)})`,
        phoneNumber: phoneInput,
        authMethod: 'mobile_otp',
        lastSyncedAt: new Date().toISOString(),
      });
      setOtpStep('phone');
      setGeneratedOtpHint(null);
      setOtpMessage(`Verified mobile number ${phoneInput} and synced profile.`);
      await onTriggerServerSync();
    } catch {
      if (generatedOtpHint && otpInput.trim() === generatedOtpHint) {
        onUpdateProfile({
          ...state.profile,
          uid: `otp_${phoneInput.replace(/[^0-9]/g, '')}`,
          displayName: `Aspirant (${phoneInput.slice(-4)})`,
          phoneNumber: phoneInput,
          authMethod: 'mobile_otp',
          lastSyncedAt: new Date().toISOString(),
        });
        setOtpStep('phone');
        setOtpMessage(`Verified mobile number ${phoneInput} locally.`);
      } else {
        setOtpError('Invalid OTP verification code.');
      }
    }
  };

  const handleExportLocalBackupJson = () => {
    const blob = new Blob([JSON.stringify(state, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pariksha_ai_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Profile & Sync Status Overview */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono-num">
            <span>User ID: {state.profile.uid}</span>
            <span aria-hidden="true">·</span>
            <span>
              Auth:{' '}
              {state.profile.authMethod === 'google'
                ? 'Google Account'
                : state.profile.authMethod === 'mobile_otp'
                ? `Mobile OTP (${state.profile.phoneNumber})`
                : 'Local Device Profile'}
            </span>
          </div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white">
            {state.profile.displayName}
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Last Synced:{' '}
            {state.profile.lastSyncedAt
              ? new Date(state.profile.lastSyncedAt).toLocaleString()
              : 'Never'}
          </p>
        </div>

        {/* Explicit Sync Status Indicator: Synced, Syncing, Offline, Failed */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex items-center gap-2 text-xs font-semibold">
            <Cloud className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            <span className="text-slate-500 dark:text-slate-400">Sync Status:</span>
            <span
              data-testid="sync-status-label"
              className={
                syncStatus === 'Synced'
                  ? 'text-emerald-600 dark:text-emerald-400'
                  : syncStatus === 'Syncing'
                  ? 'text-teal-600 dark:text-teal-400'
                  : syncStatus === 'Offline'
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-rose-600 dark:text-rose-400'
              }
            >
              {syncStatus}
            </span>
          </div>

          <button
            type="button"
            onClick={onTriggerServerSync}
            disabled={syncStatus === 'Syncing'}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
          >
            <RefreshCw
              className={`w-3.5 h-3.5 ${
                syncStatus === 'Syncing' ? 'animate-spin' : ''
              }`}
            />
            <span>Sync Now</span>
          </button>
        </div>
      </section>

      {/* Two-Column Split: Authentication (Google Sign-In + Mobile OTP) & Google Drive Cloud Backup */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Google Sign-In & Google Drive Backup */}
        <section className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Google Sign-In & Google Drive Data Backup
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Sign in with Google to back up and restore your uploaded PDFs, OCR notes, 5-attempt test history, and custom trackers in your personal Google Drive.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Official Google Sign-In Material Button */}
            <button
              type="button"
              onClick={handleGoogleLoginClick}
              disabled={isSigningInGoogle}
              className="gsi-material-button"
            >
              <div className="gsi-material-button-state"></div>
              <div className="gsi-material-button-content-wrapper">
                <div className="gsi-material-button-icon">
                  <svg
                    version="1.1"
                    xmlns="http://www.w3.org/2000/svg"
                    viewBox="0 0 48 48"
                    style={{ display: 'block' }}
                  >
                    <path
                      fill="#EA4335"
                      d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                    ></path>
                    <path
                      fill="#4285F4"
                      d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                    ></path>
                    <path
                      fill="#FBBC05"
                      d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                    ></path>
                    <path
                      fill="#34A853"
                      d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                    ></path>
                    <path fill="none" d="M0 0h48v48H0z"></path>
                  </svg>
                </div>
                <span className="gsi-material-button-contents">
                  {hasDriveToken ? 'Reconnect Google Drive' : 'Sign in with Google'}
                </span>
                <span style={{ display: 'none' }}>Sign in with Google</span>
              </div>
            </button>

            {state.profile.authMethod === 'google' && (
              <button
                type="button"
                onClick={async () => {
                  await logoutGoogle();
                  setHasDriveToken(false);
                  onUpdateProfile({
                    ...state.profile,
                    authMethod: 'local',
                  });
                }}
                className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 flex items-center gap-1.5"
              >
                <LogOut className="w-4 h-4" />
                <span>Sign Out</span>
              </button>
            )}
          </div>

          {driveStatusMsg && (
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-700 dark:text-slate-300">
              {driveStatusMsg}
            </div>
          )}

          {/* Google Drive Backup Controls */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                Google Drive Backups ({driveFiles.length})
              </span>
              <div className="flex items-center gap-2">
                {hasDriveToken && (
                  <button
                    type="button"
                    disabled={driveLoading}
                    onClick={() =>
                      handleCreateOrUpdateDriveBackup(driveFiles[0])
                    }
                    className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5"
                  >
                    <UploadCloud className="w-4 h-4" />
                    <span>
                      {driveFiles.length > 0
                        ? 'Update Drive Backup'
                        : 'Create Drive Backup'}
                    </span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleExportLocalBackupJson}
                  className="min-h-[40px] px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Export Local JSON</span>
                </button>
              </div>
            </div>

            {driveFiles.length > 0 && (
              <div className="space-y-2">
                {driveFiles.map((file) => (
                  <div
                    key={file.id}
                    className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <p className="font-bold text-slate-900 dark:text-white">
                        {file.name}
                      </p>
                      <p className="text-slate-500 font-mono-num">
                        Modified: {new Date(file.modifiedTime).toLocaleString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        onClick={() =>
                          setConfirmAction({ type: 'restore_drive', file })
                        }
                        className="min-h-[36px] px-3 py-1 rounded-lg bg-teal-600 text-white font-semibold"
                      >
                        Restore
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete Drive backup ${file.name}`}
                        onClick={() =>
                          setConfirmAction({ type: 'delete_drive', file })
                        }
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>

        {/* Right: Mobile Number OTP Login + Day/Night Theme + PWA Install */}
        <section className="lg:col-span-6 space-y-6">
          {/* Mobile Number OTP Login Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-teal-600 dark:text-teal-400" />
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Mobile Number OTP Login
              </h2>
            </div>

            {otpStep === 'phone' ? (
              <form onSubmit={handleSendOtp} className="space-y-3">
                <div>
                  <label
                    htmlFor="mobile-phone-input"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    10-Digit Mobile Number
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="mobile-phone-input"
                      type="tel"
                      required
                      value={phoneInput}
                      onChange={(e) => setPhoneInput(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="flex-1 min-h-[44px] px-3.5 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                    />
                    <button
                      type="submit"
                      className="min-h-[44px] px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold whitespace-nowrap"
                    >
                      Send OTP
                    </button>
                  </div>
                </div>
              </form>
            ) : (
              <form onSubmit={handleVerifyOtp} className="space-y-3">
                <div>
                  <label
                    htmlFor="mobile-otp-input"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Enter 6-Digit OTP Sent to {phoneInput}
                  </label>
                  <div className="flex gap-2">
                    <input
                      id="mobile-otp-input"
                      type="text"
                      maxLength={6}
                      required
                      value={otpInput}
                      onChange={(e) => setOtpInput(e.target.value)}
                      placeholder="6-digit OTP"
                      className="flex-1 min-h-[44px] px-3.5 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                    />
                    <button
                      type="submit"
                      className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold whitespace-nowrap"
                    >
                      Verify & Login
                    </button>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setOtpStep('phone')}
                  className="text-xs text-slate-500 hover:underline"
                >
                  Change mobile number
                </button>
              </form>
            )}

            {otpMessage && (
              <p className="text-xs text-emerald-600 dark:text-emerald-400 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{otpMessage}</span>
              </p>
            )}
            {otpError && (
              <p className="text-xs text-rose-600 dark:text-rose-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                <span>{otpError}</span>
              </p>
            )}
          </div>

          {/* Day / Night / System Theme Switcher & Android PWA Installation */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Day / Night Theme & Android App Install
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Choose Light Mode, Dark Mode, or System Default. Your theme preference is saved automatically with high-contrast Devanagari Hindi typography.
            </p>

            <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800">
              <button
                type="button"
                onClick={() => onUpdateTheme('light')}
                className={`min-h-[44px] rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  state.theme === 'light'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Sun className="w-4 h-4" />
                <span>Light</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateTheme('dark')}
                className={`min-h-[44px] rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  state.theme === 'dark'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Moon className="w-4 h-4" />
                <span>Dark</span>
              </button>

              <button
                type="button"
                onClick={() => onUpdateTheme('system')}
                className={`min-h-[44px] rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors ${
                  state.theme === 'system'
                    ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                }`}
              >
                <Monitor className="w-4 h-4" />
                <span>System</span>
              </button>
            </div>

            {!isInstalled && (isInstallable || isIOS) && (
              <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-bold text-slate-900 dark:text-white">
                    Install Pariksha AI on Home Screen
                  </p>
                  <p className="text-xs text-slate-500">
                    Launch full-screen on Android/iOS with instant offline access
                  </p>
                </div>
                {isInstallable ? (
                  <button
                    type="button"
                    onClick={install}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold whitespace-nowrap"
                  >
                    Install App
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowIOSGuide(true)}
                    className="min-h-[42px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold"
                  >
                    Install on iOS
                  </button>
                )}
              </div>
            )}
          </div>
        </section>
      </div>

      {/* Mandatory User Confirmation Dialog for Google Drive Operations */}
      {confirmAction && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              {confirmAction.type === 'overwrite_drive'
                ? `Update "${confirmAction.file.name}" in Google Drive?`
                : confirmAction.type === 'delete_drive'
                ? `Delete "${confirmAction.file.name}" from Google Drive?`
                : `Restore Study Data from "${confirmAction.file.name}"?`}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              {confirmAction.type === 'overwrite_drive'
                ? `This will overwrite the existing backup file "${confirmAction.file.name}" in your Google Drive with your current ${state.documents.length} documents, ${state.tests.length} tests, and study tracker progress.`
                : confirmAction.type === 'delete_drive'
                ? `Are you sure you want to permanently delete "${confirmAction.file.name}" from your Google Drive? This action cannot be undone.`
                : `This will replace your current local study data with the backup stored in "${confirmAction.file.name}" from Google Drive.`}
            </p>
            <div className="flex justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setConfirmAction(null)}
                className="min-h-[42px] px-4 py-2 text-xs font-medium rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  if (confirmAction.type === 'overwrite_drive') {
                    executeDriveBackupSave(confirmAction.file.id);
                  } else if (confirmAction.type === 'delete_drive') {
                    executeDriveDelete(confirmAction.file);
                  } else {
                    executeDriveRestore(confirmAction.file);
                  }
                }}
                className={`min-h-[42px] px-4 py-2 text-xs font-semibold rounded-xl text-white ${
                  confirmAction.type === 'delete_drive'
                    ? 'bg-rose-600 hover:bg-rose-700'
                    : 'bg-teal-600 hover:bg-teal-700'
                }`}
              >
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* iOS Install Modal */}
      {showIOSGuide && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
        >
          <div className="w-full max-w-sm rounded-2xl bg-white dark:bg-slate-900 p-6 space-y-4">
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Install Pariksha AI on iOS
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
              1. Tap the <strong>Share</strong> button in Safari toolbar.
              <br />
              2. Scroll down and select <strong>Add to Home Screen</strong>.
            </p>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="w-full min-h-[42px] rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
