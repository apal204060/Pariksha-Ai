import React, { useState } from 'react';
import {
  AppState,
  MilestoneItem,
  TrackerAutoMetric,
  TrackerCategory,
} from '../types/study';
import {
  analyzeStrongAndWeakAreas,
  computeAutoMetrics,
  getTodayIsoDate,
} from '../utils/studyEngine';
import {
  Plus,
  ArrowUp,
  ArrowDown,
  Eye,
  EyeOff,
  Trash2,
  Edit3,
  Check,
  CheckCircle2,
  Circle,
  BarChart3,
  Sliders,
} from 'lucide-react';

interface CustomTrackerViewProps {
  state: AppState;
  onUpdateCategories: (categories: TrackerCategory[]) => void;
  onUpdateMilestones: (milestones: MilestoneItem[]) => void;
  onUpdateStrongWeakAreas: (strong: string[], weak: string[]) => void;
}

export const CustomTrackerView: React.FC<CustomTrackerViewProps> = ({
  state,
  onUpdateCategories,
  onUpdateMilestones,
  onUpdateStrongWeakAreas,
}) => {
  const [showHidden, setShowHidden] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingCatId, setEditingCatId] = useState<string | null>(null);
  const [editDraft, setEditDraft] = useState<TrackerCategory | null>(null);

  // Create new category form state
  const [newName, setNewName] = useState('');
  const [newUnit, setNewUnit] = useState('hrs');
  const [newTarget, setNewTarget] = useState('10');
  const [newPeriod, setNewPeriod] = useState<'Daily' | 'Weekly' | 'Monthly' | 'Overall'>('Weekly');
  const [newAutoMetric, setNewAutoMetric] = useState<TrackerAutoMetric>('custom_manual');
  const [newInitialManual, setNewInitialManual] = useState('0');

  // Milestones form state
  const [newMilestoneTitle, setNewMilestoneTitle] = useState('');
  const [newMilestoneDate, setNewMilestoneDate] = useState(getTodayIsoDate());

  // Custom Strong / Weak Area input
  const [newStrongInput, setNewStrongInput] = useState('');
  const [newWeakInput, setNewWeakInput] = useState('');

  const autoMetrics = computeAutoMetrics(state);
  const { strongAreas, weakAreas } = analyzeStrongAndWeakAreas(state.tests);

  const sortedCategories = [...state.trackerCategories].sort(
    (a, b) => a.order - b.order
  );
  const visibleCategories = showHidden
    ? sortedCategories
    : sortedCategories.filter((c) => !c.hidden);

  const handleAdjustManualDelta = (catId: string, delta: number) => {
    const updated = state.trackerCategories.map((c) => {
      if (c.id !== catId) return c;
      const nextManual = Number((c.manualAdjustment + delta).toFixed(1));
      return {
        ...c,
        manualAdjustment: nextManual,
      };
    });
    onUpdateCategories(updated);
  };

  const handleMoveCategory = (index: number, direction: -1 | 1) => {
    const list = [...sortedCategories];
    const targetIdx = index + direction;
    if (targetIdx < 0 || targetIdx >= list.length) return;
    const tempOrder = list[index].order;
    list[index] = { ...list[index], order: list[targetIdx].order };
    list[targetIdx] = { ...list[targetIdx], order: tempOrder };
    onUpdateCategories(list);
  };

  const handleToggleHideCategory = (catId: string) => {
    const updated = state.trackerCategories.map((c) =>
      c.id === catId ? { ...c, hidden: !c.hidden } : c
    );
    onUpdateCategories(updated);
  };

  const handleDeleteCategory = (catId: string) => {
    const updated = state.trackerCategories.filter((c) => c.id !== catId);
    onUpdateCategories(updated);
  };

  const handleSaveEditCategory = () => {
    if (!editDraft || !editDraft.name.trim()) return;
    const updated = state.trackerCategories.map((c) =>
      c.id === editDraft.id ? editDraft : c
    );
    onUpdateCategories(updated);
    setEditingCatId(null);
    setEditDraft(null);
  };

  const handleCreateCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    const maxOrder = state.trackerCategories.reduce(
      (max, c) => Math.max(max, c.order),
      0
    );
    const manualVal = parseFloat(newInitialManual) || 0;
    const newCat: TrackerCategory = {
      id: `cat_${Date.now()}`,
      name: newName.trim(),
      unit: newUnit.trim() || 'pts',
      targetValue: Math.max(1, parseFloat(newTarget) || 10),
      autoMetric: newAutoMetric,
      manualAdjustment: manualVal,
      currentValue: manualVal,
      hidden: false,
      order: maxOrder + 1,
      period: newPeriod,
    };
    onUpdateCategories([...state.trackerCategories, newCat]);
    setNewName('');
    setNewInitialManual('0');
    setShowCreateModal(false);
  };

  const handleAddMilestone = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMilestoneTitle.trim()) return;
    const item: MilestoneItem = {
      id: `ms_${Date.now()}`,
      title: newMilestoneTitle.trim(),
      targetDate: newMilestoneDate,
      completed: false,
    };
    onUpdateMilestones([...state.milestones, item]);
    setNewMilestoneTitle('');
  };

  // Compute last 7 days study hours for Weekly Progress Bar Chart
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(Date.now() - (6 - i) * 86400000);
    const iso = d.toISOString().slice(0, 10);
    const label = d.toLocaleDateString('en-US', { weekday: 'short' });
    const hours = state.studyLogs
      .filter((l) => l.date === iso)
      .reduce((sum, l) => sum + l.hours, 0);
    return { iso, label, hours: Number(hours.toFixed(1)) };
  });

  const hiddenCount = state.trackerCategories.filter((c) => c.hidden).length;

  return (
    <div className="space-y-8">
      {/* Header & Category Controls */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            Customizable Selection Tracker & Analytics
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            Create, rename, reorder, hide, or delete your own tracking categories. All metrics sync automatically from your study sessions and test attempts while allowing manual adjustments.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 self-start sm:self-auto">
          {hiddenCount > 0 && (
            <button
              type="button"
              onClick={() => setShowHidden((h) => !h)}
              className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5 whitespace-nowrap"
            >
              {showHidden ? (
                <>
                  <EyeOff className="w-4 h-4" />
                  <span>Hide Hidden ({hiddenCount})</span>
                </>
              ) : (
                <>
                  <Eye className="w-4 h-4" />
                  <span>Show Hidden ({hiddenCount})</span>
                </>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={() => setShowCreateModal(true)}
            className="min-h-[44px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            <span>Add Custom Tracker Category</span>
          </button>
        </div>
      </section>

      {/* Customizable Tracker Categories Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {visibleCategories.map((cat, idx) => {
          const isEditing = editingCatId === cat.id && editDraft;
          const pct = Math.min(
            100,
            Math.round((cat.currentValue / Math.max(1, cat.targetValue)) * 100)
          );
          const isAuto = cat.autoMetric !== 'custom_manual';

          return (
            <div
              key={cat.id}
              className={`bg-white dark:bg-slate-900 border rounded-2xl p-5 space-y-4 transition-opacity ${
                cat.hidden
                  ? 'border-dashed border-slate-300 dark:border-slate-700 opacity-65'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              {isEditing ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                        Category Name
                      </label>
                      <input
                        type="text"
                        value={editDraft.name}
                        onChange={(e) =>
                          setEditDraft({ ...editDraft, name: e.target.value })
                        }
                        className="w-full min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Target
                        </label>
                        <input
                          type="number"
                          step="0.5"
                          value={editDraft.targetValue}
                          onChange={(e) =>
                            setEditDraft({
                              ...editDraft,
                              targetValue: parseFloat(e.target.value) || 1,
                            })
                          }
                          className="w-full min-h-[40px] px-2.5 py-1.5 text-xs font-mono-num rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                          Unit
                        </label>
                        <input
                          type="text"
                          value={editDraft.unit}
                          onChange={(e) =>
                            setEditDraft({ ...editDraft, unit: e.target.value })
                          }
                          className="w-full min-h-[40px] px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                        Period
                      </label>
                      <select
                        value={editDraft.period}
                        onChange={(e) =>
                          setEditDraft({
                            ...editDraft,
                            period: e.target.value as TrackerCategory['period'],
                          })
                        }
                        className="w-full min-h-[40px] px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                      >
                        <option value="Daily">Daily</option>
                        <option value="Weekly">Weekly</option>
                        <option value="Monthly">Monthly</option>
                        <option value="Overall">Overall</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-[11px] font-semibold text-slate-500 mb-1">
                        Manual Adjustment (+/-)
                      </label>
                      <input
                        type="number"
                        step="0.5"
                        value={editDraft.manualAdjustment}
                        onChange={(e) =>
                          setEditDraft({
                            ...editDraft,
                            manualAdjustment: parseFloat(e.target.value) || 0,
                          })
                        }
                        className="w-full min-h-[40px] px-2.5 py-1.5 text-xs font-mono-num rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                      />
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingCatId(null);
                        setEditDraft(null);
                      }}
                      className="min-h-[38px] px-3 py-1 text-xs rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                    >
                      Cancel
                    </button>
                    <button
                      type="button"
                      onClick={handleSaveEditCategory}
                      className="min-h-[38px] px-3.5 py-1 text-xs font-semibold rounded-lg bg-teal-600 text-white flex items-center gap-1"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>Save Changes</span>
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5 text-xs text-slate-500 dark:text-slate-400">
                        <span>{cat.period} Target</span>
                        <span aria-hidden="true">·</span>
                        <span>{isAuto ? 'Auto-Synced + Manual' : 'Custom Goal'}</span>
                        {cat.hidden && (
                          <>
                            <span aria-hidden="true">·</span>
                            <span className="text-amber-600">Hidden</span>
                          </>
                        )}
                      </div>
                      <h2 className="text-base font-bold text-slate-900 dark:text-white mt-0.5">
                        {cat.name}
                      </h2>
                    </div>

                    {/* Reorder, Edit, Hide, Delete Controls */}
                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        aria-label={`Move ${cat.name} up`}
                        disabled={idx === 0}
                        onClick={() => handleMoveCategory(idx, -1)}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white disabled:opacity-30"
                      >
                        <ArrowUp className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={`Move ${cat.name} down`}
                        disabled={idx === visibleCategories.length - 1}
                        onClick={() => handleMoveCategory(idx, 1)}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white disabled:opacity-30"
                      >
                        <ArrowDown className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={`Edit ${cat.name}`}
                        onClick={() => {
                          setEditingCatId(cat.id);
                          setEditDraft({ ...cat });
                        }}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        type="button"
                        aria-label={cat.hidden ? `Show ${cat.name}` : `Hide ${cat.name}`}
                        onClick={() => handleToggleHideCategory(cat.id)}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-slate-900 dark:hover:text-white"
                      >
                        {cat.hidden ? (
                          <Eye className="w-4 h-4" />
                        ) : (
                          <EyeOff className="w-4 h-4" />
                        )}
                      </button>
                      <button
                        type="button"
                        aria-label={`Delete ${cat.name}`}
                        onClick={() => handleDeleteCategory(cat.id)}
                        className="min-h-[36px] min-w-[36px] flex items-center justify-center rounded-lg text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Value & Custom Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex items-baseline justify-between">
                      <div className="flex items-baseline gap-1.5">
                        <span className="text-2xl font-bold font-mono-num text-slate-900 dark:text-white">
                          {cat.currentValue}
                        </span>
                        <span className="text-xs font-mono-num text-slate-500 dark:text-slate-400">
                          / {cat.targetValue} {cat.unit}
                        </span>
                      </div>
                      <span className="text-xs font-mono-num font-bold text-teal-600 dark:text-teal-400">
                        {pct}%
                      </span>
                    </div>

                    <div className="w-full h-2.5 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-teal-600 dark:bg-teal-400 rounded-full transition-all duration-300"
                        style={{ width: `${pct}%` }}
                      />
                    </div>
                  </div>

                  {/* Quick Manual Adjustment Buttons */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
                    <span className="text-slate-500 dark:text-slate-400 font-mono-num">
                      {isAuto
                        ? `Auto: ${autoMetrics[cat.autoMetric] ?? 0} ${cat.unit} ${
                            cat.manualAdjustment !== 0
                              ? `(Manual ${cat.manualAdjustment > 0 ? '+' : ''}${
                                  cat.manualAdjustment
                                })`
                              : ''
                          }`
                        : 'Manual Counter'}
                    </span>

                    <div className="flex items-center gap-1.5">
                      <button
                        type="button"
                        aria-label={`Decrease ${cat.name}`}
                        onClick={() =>
                          handleAdjustManualDelta(
                            cat.id,
                            cat.unit === 'hrs' ? -0.5 : -1
                          )
                        }
                        className="min-h-[34px] px-2.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 font-mono-num font-bold text-slate-800 dark:text-slate-200"
                      >
                        -{cat.unit === 'hrs' ? '0.5' : '1'}
                      </button>
                      <button
                        type="button"
                        aria-label={`Increase ${cat.name}`}
                        onClick={() =>
                          handleAdjustManualDelta(
                            cat.id,
                            cat.unit === 'hrs' ? 0.5 : 1
                          )
                        }
                        className="min-h-[34px] px-2.5 rounded-lg bg-teal-600/15 hover:bg-teal-600/25 font-mono-num font-bold text-teal-700 dark:text-teal-300"
                      >
                        +{cat.unit === 'hrs' ? '0.5' : '1'}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          );
        })}
      </section>

      {/* Two-Column Split: 7-Day Study Progress Chart + Strong & Weak Areas */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Weekly / Monthly Progress Bar Chart */}
        <section className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <span>7-Day Study Hours & Monthly Overview</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Daily Target: {state.diagnostic.dailyHoursTarget} hrs/day · Weekly Total:{' '}
                {autoMetrics.weekly_study_hours} hrs
              </p>
            </div>
          </div>

          {/* 7-Day Visual Bar Chart */}
          <div className="grid grid-cols-7 gap-2 items-end h-44 pt-4 px-2 bg-slate-50 dark:bg-slate-950 rounded-xl p-4 border border-slate-200/80 dark:border-slate-800">
            {last7Days.map((day) => {
              const maxBarHours = Math.max(8, state.diagnostic.dailyHoursTarget);
              const heightPct = Math.min(
                100,
                Math.max(8, Math.round((day.hours / maxBarHours) * 100))
              );
              const hitGoal = day.hours >= state.diagnostic.dailyHoursTarget;
              return (
                <div
                  key={day.iso}
                  className="flex flex-col items-center justify-end h-full gap-1.5"
                >
                  <span className="text-[11px] font-mono-num font-semibold text-slate-700 dark:text-slate-300">
                    {day.hours}h
                  </span>
                  <div className="w-full max-w-[32px] bg-slate-200 dark:bg-slate-800 rounded-t-lg h-28 flex items-end overflow-hidden">
                    <div
                      className={`w-full rounded-t-lg transition-all duration-300 ${
                        hitGoal
                          ? 'bg-teal-600 dark:bg-teal-400'
                          : 'bg-slate-700 dark:bg-slate-400'
                      }`}
                      style={{ height: `${heightPct}%` }}
                    />
                  </div>
                  <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400">
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/70 dark:border-slate-800">
              <p className="text-xs text-slate-500">Tests Completed</p>
              <p className="text-lg font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
                {autoMetrics.tests_completed}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/70 dark:border-slate-800">
              <p className="text-xs text-slate-500">Avg Accuracy</p>
              <p className="text-lg font-bold font-mono-num text-teal-600 dark:text-teal-400 mt-0.5">
                {autoMetrics.average_accuracy}%
              </p>
            </div>
            <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/70 dark:border-slate-800">
              <p className="text-xs text-slate-500">Best Accuracy</p>
              <p className="text-lg font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
                {autoMetrics.best_accuracy}%
              </p>
            </div>
          </div>
        </section>

        {/* Strong and Weak Areas + Personal Goals & Milestones */}
        <section className="lg:col-span-6 space-y-6">
          {/* Strong & Weak Areas Card */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-teal-600 dark:text-teal-400" />
              <span>Strong & Weak Areas (Auto-Analyzed + Custom)</span>
            </h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Strong Areas */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-3">
                <p className="text-xs font-bold text-emerald-700 dark:text-emerald-400">
                  Strong Areas (≥ 70% Accuracy)
                </p>
                <div className="space-y-1.5 text-xs">
                  {strongAreas.map((s) => (
                    <div
                      key={s.topic}
                      className="flex items-center justify-between text-slate-800 dark:text-slate-200"
                    >
                      <span>{s.topic}</span>
                      <span className="font-mono-num font-bold text-emerald-600 dark:text-emerald-400">
                        {s.accuracy}%
                      </span>
                    </div>
                  ))}
                  {state.customStrongAreas.map((area) => (
                    <div
                      key={area}
                      className="flex items-center justify-between text-slate-700 dark:text-slate-300"
                    >
                      <span>{area}</span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateStrongWeakAreas(
                            state.customStrongAreas.filter((a) => a !== area),
                            state.customWeakAreas
                          )
                        }
                        className="text-slate-400 hover:text-rose-500 text-[11px]"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-1.5 pt-1">
                  <input
                    type="text"
                    value={newStrongInput}
                    onChange={(e) => setNewStrongInput(e.target.value)}
                    placeholder="Add strong topic..."
                    className="flex-1 min-h-[36px] px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newStrongInput.trim()) return;
                      onUpdateStrongWeakAreas(
                        [...state.customStrongAreas, newStrongInput.trim()],
                        state.customWeakAreas
                      );
                      setNewStrongInput('');
                    }}
                    className="min-h-[36px] px-2.5 text-xs font-semibold rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                  >
                    + Add
                  </button>
                </div>
              </div>

              {/* Weak Areas */}
              <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 space-y-3">
                <p className="text-xs font-bold text-rose-700 dark:text-rose-400">
                  Weak / Focus Areas (&lt; 70% Accuracy)
                </p>
                <div className="space-y-1.5 text-xs">
                  {weakAreas.map((w) => (
                    <div
                      key={w.topic}
                      className="flex items-center justify-between text-slate-800 dark:text-slate-200"
                    >
                      <span>{w.topic}</span>
                      <span className="font-mono-num font-bold text-rose-600 dark:text-rose-400">
                        {w.accuracy}%
                      </span>
                    </div>
                  ))}
                  {state.customWeakAreas.map((area) => (
                    <div
                      key={area}
                      className="flex items-center justify-between text-slate-700 dark:text-slate-300"
                    >
                      <span>{area}</span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateStrongWeakAreas(
                            state.customStrongAreas,
                            state.customWeakAreas.filter((a) => a !== area)
                          )
                        }
                        className="text-slate-400 hover:text-rose-500 text-[11px]"
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>

                <div className="flex gap-1.5 pt-1">
                  <input
                    type="text"
                    value={newWeakInput}
                    onChange={(e) => setNewWeakInput(e.target.value)}
                    placeholder="Add weak topic..."
                    className="flex-1 min-h-[36px] px-2.5 py-1 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (!newWeakInput.trim()) return;
                      onUpdateStrongWeakAreas(
                        state.customStrongAreas,
                        [...state.customWeakAreas, newWeakInput.trim()]
                      );
                      setNewWeakInput('');
                    }}
                    className="min-h-[36px] px-2.5 text-xs font-semibold rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                  >
                    + Add
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Personal Goals & Milestones */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-4">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">
              Personal Goals & Milestones
            </h2>

            <form onSubmit={handleAddMilestone} className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={newMilestoneTitle}
                onChange={(e) => setNewMilestoneTitle(e.target.value)}
                placeholder="Add personal milestone (e.g. Complete 10 Full Mock Tests)..."
                className="flex-1 min-h-[42px] px-3 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
              />
              <div className="flex gap-2">
                <input
                  type="date"
                  value={newMilestoneDate}
                  onChange={(e) => setNewMilestoneDate(e.target.value)}
                  className="min-h-[42px] px-2.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
                <button
                  type="submit"
                  className="min-h-[42px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold whitespace-nowrap"
                >
                  + Add Milestone
                </button>
              </div>
            </form>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {state.milestones.map((ms) => (
                <div
                  key={ms.id}
                  className="py-2.5 flex items-center justify-between gap-3"
                >
                  <button
                    type="button"
                    onClick={() =>
                      onUpdateMilestones(
                        state.milestones.map((m) =>
                          m.id === ms.id ? { ...m, completed: !m.completed } : m
                        )
                      )
                    }
                    className="flex items-start gap-2.5 text-left flex-1 min-h-[40px] py-1"
                  >
                    {ms.completed ? (
                      <CheckCircle2 className="w-4 h-4 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                    ) : (
                      <Circle className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p
                        className={`text-xs sm:text-sm font-medium ${
                          ms.completed
                            ? 'line-through text-slate-400'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {ms.title}
                      </p>
                      <p className="text-[11px] font-mono-num text-slate-500">
                        Target Date: {ms.targetDate}
                      </p>
                    </div>
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete milestone ${ms.title}`}
                    onClick={() =>
                      onUpdateMilestones(
                        state.milestones.filter((m) => m.id !== ms.id)
                      )
                    }
                    className="min-h-[38px] min-w-[38px] flex items-center justify-center text-slate-400 hover:text-rose-600"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>

      {/* Add Custom Tracker Category Modal */}
      {showCreateModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-tracker-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-md bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h2
                id="add-tracker-modal-title"
                className="text-lg font-bold text-slate-900 dark:text-white"
              >
                Create Custom Tracking Category
              </h2>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="min-h-[40px] px-2 text-xs text-slate-500"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleCreateCategory} className="space-y-4">
              <div>
                <label
                  htmlFor="new-cat-name"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Category Name
                </label>
                <input
                  id="new-cat-name"
                  type="text"
                  required
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  placeholder="e.g., Quantitative Aptitude Drills"
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="new-cat-target"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Target Value
                  </label>
                  <input
                    id="new-cat-target"
                    type="number"
                    step="0.5"
                    min="1"
                    required
                    value={newTarget}
                    onChange={(e) => setNewTarget(e.target.value)}
                    className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label
                    htmlFor="new-cat-unit"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Unit Label
                  </label>
                  <input
                    id="new-cat-unit"
                    type="text"
                    required
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value)}
                    placeholder="hrs, Q, sets, %"
                    className="w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label
                    htmlFor="new-cat-period"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Tracking Period
                  </label>
                  <select
                    id="new-cat-period"
                    value={newPeriod}
                    onChange={(e) =>
                      setNewPeriod(e.target.value as TrackerCategory['period'])
                    }
                    className="w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    <option value="Daily">Daily</option>
                    <option value="Weekly">Weekly</option>
                    <option value="Monthly">Monthly</option>
                    <option value="Overall">Overall</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="new-cat-source"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Data Source
                  </label>
                  <select
                    id="new-cat-source"
                    value={newAutoMetric}
                    onChange={(e) =>
                      setNewAutoMetric(e.target.value as TrackerAutoMetric)
                    }
                    className="w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    <option value="custom_manual">Manual Counter</option>
                    <option value="daily_study_hours">Auto: Daily Study Hours</option>
                    <option value="weekly_study_hours">Auto: Weekly Study Hours</option>
                    <option value="tests_completed">Auto: Completed Tests</option>
                    <option value="total_attempts">Auto: Total Test Attempts</option>
                    <option value="average_accuracy">Auto: Average Accuracy %</option>
                  </select>
                </div>
              </div>

              <div>
                <label
                  htmlFor="new-cat-initial"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Initial Starting Value / Offset
                </label>
                <input
                  id="new-cat-initial"
                  type="number"
                  step="0.5"
                  value={newInitialManual}
                  onChange={(e) => setNewInitialManual(e.target.value)}
                  className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="min-h-[44px] px-4 py-2 text-xs font-medium rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 text-xs font-semibold rounded-xl bg-teal-600 hover:bg-teal-700 text-white"
                >
                  Create Category
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
