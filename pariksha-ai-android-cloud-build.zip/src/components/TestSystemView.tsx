import React, { useEffect, useState } from 'react';
import {
  MCQQuestion,
  OptionKey,
  StudyDocument,
  TestAttempt,
  TestItem,
} from '../types/study';
import {
  buildFallbackQuestionsFromText,
  canRetakeTest,
  compareTestAttempts,
  evaluateTestAttempt,
  getRemainingAttempts,
  getSelectedPagesText,
   getTodayIsoDate,
  MAX_TEST_ATTEMPTS,
  prepareRandomizedTestRun,
  RandomizedQuestionView,
} from '../utils/studyEngine';
import {
  Clock,
  Sparkles,
  RotateCcw,
  CheckCircle2,
  XCircle,
  BookOpen,
  Shuffle,
  Play,
  Send,
  ArrowLeft,
  TrendingUp,
  HelpCircle,
} from 'lucide-react';

interface TestSystemViewProps {
  tests: TestItem[];
  documents: StudyDocument[];
  preselectedDocId?: string | null;
  onClearPreselectedDoc: () => void;
  onCreateTest: (test: TestItem) => void;
  onRecordTestAttempt: (testId: string, attempt: TestAttempt) => void;
}

export const TestSystemView: React.FC<TestSystemViewProps> = ({
  tests,
  documents,
  preselectedDocId,
  onClearPreselectedDoc,
  onCreateTest,
  onRecordTestAttempt,
}) => {
  const [selectedTestId, setSelectedTestId] = useState<string>(
    tests[0]?.id || ''
  );
  const [mode, setMode] = useState<'overview' | 'running' | 'solutions'>('overview');

  // New Test Generator Modal State
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [genDocId, setGenDocId] = useState<string>(documents[0]?.id || '');
  const [genTitle, setGenTitle] = useState('');
  const [genQuestionCount, setGenQuestionCount] = useState(4);
  const [genIsTimed, setGenIsTimed] = useState(true);
  const [genTimeMinutes, setGenTimeMinutes] = useState(10);
  const [genRandomQuestions, setGenRandomQuestions] = useState(true);
  const [genRandomOptions, setGenRandomOptions] = useState(false);
  const [isGeneratingTest, setIsGeneratingTest] = useState(false);

  // Active Test Run State
  const [runViews, setRunViews] = useState<RandomizedQuestionView[]>([]);
  const [currentQuestionIdx, setCurrentQuestionIdx] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, OptionKey | null>>({});
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [runRandomQ, setRunRandomQ] = useState(false);
  const [runRandomOpt, setRunRandomOpt] = useState(false);

  // Selected Attempt in Solutions View
  const [inspectedAttemptId, setInspectedAttemptId] = useState<string | null>(null);

  // Interactive AI Teacher Doubt State per question
  const [doubtInputs, setDoubtInputs] = useState<Record<string, string>>({});
  const [doubtLoadingId, setDoubtLoadingId] = useState<string | null>(null);
  const [doubtReplies, setDoubtReplies] = useState<
    Record<string, { englishReply: string; hindiReply: string }>
  >({});

  const selectedTest =
    tests.find((t) => t.id === selectedTestId) || tests[0] || null;

  // Open generator automatically if navigated from Upload view with a document ID
  useEffect(() => {
    if (preselectedDocId) {
      const targetDoc = documents.find((d) => d.id === preselectedDocId);
      if (targetDoc) {
        setGenDocId(targetDoc.id);
        setGenTitle(`${targetDoc.title.slice(0, 42)} — AI MCQ Test`);
        setShowCreateModal(true);
      }
      onClearPreselectedDoc();
    }
  }, [preselectedDocId, documents, onClearPreselectedDoc]);

  // Timer during active test run
  useEffect(() => {
    if (mode !== 'running' || !selectedTest) return;
    const interval = window.setInterval(() => {
      setElapsedSeconds((prev) => {
        const next = prev + 1;
        if (
          selectedTest.isTimed &&
          next >= selectedTest.timeLimitMinutes * 60
        ) {
          // Auto-submit when timer expires
          window.clearInterval(interval);
        }
        return next;
      });
    }, 1000);
    return () => window.clearInterval(interval);
  }, [mode, selectedTest]);

  // Start or Retake a Test
  const startTestRun = (
    testToRun: TestItem,
    overrideRandomQ?: boolean,
    overrideRandomOpt?: boolean
  ) => {
    if (!canRetakeTest(testToRun)) return;
    const useRandQ = overrideRandomQ ?? testToRun.randomizeQuestions;
    const useRandOpt = overrideRandomOpt ?? testToRun.randomizeOptions;

    const prepared = prepareRandomizedTestRun(
      testToRun.questions,
      useRandQ,
      useRandOpt,
      Date.now()
    );
    setSelectedTestId(testToRun.id);
    setRunViews(prepared);
    setCurrentQuestionIdx(0);
    setSelectedAnswers({});
    setElapsedSeconds(0);
    setRunRandomQ(useRandQ);
    setRunRandomOpt(useRandOpt);
    setMode('running');
  };

  const handleSelectOption = (questionId: string, originalKey: OptionKey) => {
    setSelectedAnswers((prev) => ({
      ...prev,
      [questionId]: originalKey,
    }));
  };

  const handleSubmitActiveTest = () => {
    if (!selectedTest) return;
    const newAttempt = evaluateTestAttempt(
      selectedTest,
      selectedAnswers,
      Math.max(1, elapsedSeconds),
      runRandomQ,
      runRandomOpt
    );
    onRecordTestAttempt(selectedTest.id, newAttempt);
    setInspectedAttemptId(newAttempt.id);
    setMode('solutions');
  };

  const handleGenerateNewTest = async (e: React.FormEvent) => {
    e.preventDefault();
    const doc = documents.find((d) => d.id === genDocId) || documents[0];
    if (!doc) return;

    setIsGeneratingTest(true);
    const sourceText = getSelectedPagesText(doc);
    const title =
      genTitle.trim() || `${doc.title.slice(0, 38)} — Practice Test`;

    let generatedQuestions: MCQQuestion[] | null = null;

    try {
      const response = await fetch('/api/gemini/generate-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentTitle: doc.title,
          sourceText,
          questionCount: genQuestionCount,
        }),
      });
      if (response.ok) {
        const data = await response.json();
        if (Array.isArray(data.questions) && data.questions.length > 0) {
          generatedQuestions = data.questions;
        }
      }
    } catch (err) {
      console.error('Test generation fallback used:', err);
    }

    if (!generatedQuestions || generatedQuestions.length === 0) {
      generatedQuestions = buildFallbackQuestionsFromText(
        doc.title,
        sourceText,
        genQuestionCount
      );
    }

    const newTest: TestItem = {
      id: `test_${Date.now()}`,
      title,
      sourceDocumentId: doc.id,
      sourceDocumentTitle: doc.title,
      createdAt: getTodayIsoDate(),
      isTimed: genIsTimed,
      timeLimitMinutes: Math.max(2, genTimeMinutes),
      randomizeQuestions: genRandomQuestions,
      randomizeOptions: genRandomOptions,
      questions: generatedQuestions,
      attempts: [],
    };

    onCreateTest(newTest);
    setSelectedTestId(newTest.id);
    setIsGeneratingTest(false);
    setShowCreateModal(false);
    setGenTitle('');
  };

  const handleAskTeacherDoubt = async (q: MCQQuestion) => {
    const doubt = (doubtInputs[q.id] || '').trim();
    if (!doubt) return;
    setDoubtLoadingId(q.id);
    try {
      const res = await fetch('/api/gemini/teacher-ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          questionText: q.questionText,
          correctOptionText: `${q.correctOption}: ${q.options[q.correctOption]}`,
          studentDoubt: doubt,
          sourceExcerpt: q.teacher.sourceExcerpt,
        }),
      });
      const data = await res.json();
      setDoubtReplies((prev) => ({
        ...prev,
        [q.id]: {
          englishReply: data.englishReply,
          hindiReply: data.hindiReply,
        },
      }));
    } catch {
      setDoubtReplies((prev) => ({
        ...prev,
        [q.id]: {
          englishReply: `The correct answer is Option ${q.correctOption} ("${q.options[q.correctOption]}"), directly verified by the source excerpt: "${q.teacher.sourceExcerpt}".`,
          hindiReply: `स्रोत सामग्री के आधार पर सही उत्तर विकल्प ${q.correctOption} ("${q.options[q.correctOption]}") है।`,
        },
      }));
    } finally {
      setDoubtLoadingId(null);
    }
  };

  const formatSeconds = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
  };

  // ACTIVE TEST RUNNER VIEW
  if (mode === 'running' && selectedTest && runViews.length > 0) {
    const currentView = runViews[currentQuestionIdx];
    const currentQ = currentView.question;
    const chosenOriginalKey = selectedAnswers[currentQ.id] ?? null;
    const answeredCount = Object.values(selectedAnswers).filter(Boolean).length;
    const remainingTimeSecs = Math.max(
      0,
      selectedTest.timeLimitMinutes * 60 - elapsedSeconds
    );

    return (
      <div className="space-y-6">
        {/* Runner Top Header */}
        <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono-num">
              <span>
                Attempt #{selectedTest.attempts.length + 1} of {MAX_TEST_ATTEMPTS}
              </span>
              <span aria-hidden="true">·</span>
              <span>
                {selectedTest.isTimed
                  ? `Timed (${selectedTest.timeLimitMinutes}m)`
                  : 'Untimed Practice'}
              </span>
              {(runRandomQ || runRandomOpt) && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>Randomized</span>
                </>
              )}
            </div>
            <h1 className="text-lg font-bold text-slate-900 dark:text-white mt-0.5">
              {selectedTest.title}
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <div className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center gap-2 text-xs font-mono-num font-bold text-slate-900 dark:text-white">
              <Clock className="w-4 h-4 text-teal-600 dark:text-teal-400" />
              <span>
                {selectedTest.isTimed
                  ? `Remaining: ${formatSeconds(remainingTimeSecs)}`
                  : `Elapsed: ${formatSeconds(elapsedSeconds)}`}
              </span>
            </div>

            <button
              type="button"
              onClick={handleSubmitActiveTest}
              className="min-h-[44px] px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold whitespace-nowrap"
            >
              Submit Test ({answeredCount}/{runViews.length})
            </button>
          </div>
        </section>

        {/* Question Palette & Active Question Card */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          <section className="lg:col-span-8 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6">
            <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 font-mono-num">
              <span>
                Question {currentQuestionIdx + 1} of {runViews.length} · {currentQ.topicTag}
              </span>
              <span>Difficulty: {currentQ.difficulty}</span>
            </div>

            <div className="space-y-2">
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white leading-relaxed">
                {currentQ.questionText}
              </h2>
              {currentQ.questionHindi && (
                <p className="text-sm text-slate-600 dark:text-slate-300 font-hindi leading-relaxed">
                  {currentQ.questionHindi}
                </p>
              )}
            </div>

            {/* 4 Options */}
            <div className="space-y-3">
              {currentView.displayOptions.map((opt) => {
                const isSelected = chosenOriginalKey === opt.originalKey;
                return (
                  <button
                    key={opt.displayKey}
                    type="button"
                    onClick={() =>
                      handleSelectOption(currentQ.id, opt.originalKey)
                    }
                    className={`w-full min-h-[52px] p-4 rounded-xl border text-left flex items-start gap-3.5 transition-colors ${
                      isSelected
                        ? 'border-teal-600 bg-teal-50/60 dark:bg-teal-950/40 text-slate-900 dark:text-white'
                        : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/50 text-slate-800 dark:text-slate-200'
                    }`}
                  >
                    <span
                      className={`w-7 h-7 rounded-lg flex items-center justify-center text-xs font-bold font-mono-num shrink-0 ${
                        isSelected
                          ? 'bg-teal-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                      }`}
                    >
                      {opt.displayKey}
                    </span>
                    <span className="text-sm leading-relaxed pt-0.5">
                      {opt.text}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Bottom Controls */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  disabled={currentQuestionIdx === 0}
                  onClick={() => setCurrentQuestionIdx((i) => Math.max(0, i - 1))}
                  className="min-h-[44px] px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-semibold text-slate-800 dark:text-slate-200 disabled:opacity-40"
                >
                  Previous
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setSelectedAnswers((prev) => ({
                      ...prev,
                      [currentQ.id]: null,
                    }))
                  }
                  className="min-h-[44px] px-4 py-2 rounded-xl text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
                >
                  Clear Choice
                </button>
              </div>

              {currentQuestionIdx < runViews.length - 1 ? (
                <button
                  type="button"
                  onClick={() =>
                    setCurrentQuestionIdx((i) =>
                      Math.min(runViews.length - 1, i + 1)
                    )
                  }
                  className="min-h-[44px] px-5 py-2 rounded-xl bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold"
                >
                  Next Question
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSubmitActiveTest}
                  className="min-h-[44px] px-6 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold"
                >
                  Finish & Evaluate Test
                </button>
              )}
            </div>
          </section>

          {/* Right Question Palette */}
          <aside className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
            <h3 className="text-sm font-bold text-slate-900 dark:text-white">
              Question Palette ({answeredCount}/{runViews.length} Answered)
            </h3>
            <div className="grid grid-cols-5 gap-2">
              {runViews.map((v, idx) => {
                const isAnswered = !!selectedAnswers[v.question.id];
                const isCurrent = idx === currentQuestionIdx;
                return (
                  <button
                    key={v.question.id}
                    type="button"
                    aria-label={`Go to Question ${idx + 1}`}
                    onClick={() => setCurrentQuestionIdx(idx)}
                    className={`min-h-[44px] rounded-xl font-mono-num text-xs font-bold border transition-colors ${
                      isCurrent
                        ? 'border-teal-600 ring-2 ring-teal-600/30 bg-teal-600 text-white'
                        : isAnswered
                        ? 'border-teal-600/40 bg-teal-50 dark:bg-teal-950/40 text-teal-800 dark:text-teal-300'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-600 dark:text-slate-400'
                    }`}
                  >
                    {idx + 1}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => setMode('overview')}
              className="w-full min-h-[42px] px-4 py-2 rounded-xl border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white"
            >
              Exit Without Submitting
            </button>
          </aside>
        </div>
      </div>
    );
  }

  const comparison = selectedTest ? compareTestAttempts(selectedTest) : null;
  const activeAttempt =
    selectedTest && selectedTest.attempts.length > 0
      ? selectedTest.attempts.find((a) => a.id === inspectedAttemptId) ||
        selectedTest.attempts[selectedTest.attempts.length - 1]
      : null;

  return (
    <div className="space-y-8">
      {/* Header & Generate AI Test CTA */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            AI Test System, 5-Retake Tracker & Bilingual AI Teacher
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-300 mt-1">
            Generate timed or untimed MCQ tests from your uploaded documents, retake each test up to 5 times, compare attempt improvements, and study bilingual English + Simple Hindi AI Teacher solutions.
          </p>
        </div>

        <button
          type="button"
          onClick={() => {
            setGenDocId(documents[0]?.id || '');
            setShowCreateModal(true);
          }}
          className="min-h-[44px] px-5 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-2 whitespace-nowrap self-start sm:self-auto"
        >
          <Sparkles className="w-4 h-4" />
          <span>Generate New AI Test</span>
        </button>
      </section>

      {/* Main Split: Test Library (Left 4 cols) + Selected Test Details / Attempt Comparison / AI Teacher Solutions (Right 8 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: Test List */}
        <section className="lg:col-span-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 dark:text-white">
              Your AI Tests ({tests.length})
            </h2>
            <span className="text-xs text-slate-500 dark:text-slate-400">
              Max 5 Attempts Each
            </span>
          </div>

          <div className="space-y-3">
            {tests.map((test) => {
              const isSelected = selectedTest?.id === test.id;
              const comp = compareTestAttempts(test);
              return (
                <div
                  key={test.id}
                  className={`p-4 rounded-xl border transition-colors ${
                    isSelected
                      ? 'border-teal-600 bg-teal-50/40 dark:bg-teal-950/20'
                      : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50 dark:hover:bg-slate-800/40'
                  }`}
                >
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedTestId(test.id);
                      setInspectedAttemptId(null);
                      setMode('overview');
                    }}
                    className="w-full text-left space-y-1.5"
                  >
                    <p className="text-sm font-bold text-slate-900 dark:text-white">
                      {test.title}
                    </p>
                    <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                      Source: {test.sourceDocumentTitle}
                    </p>
                    <div className="flex flex-wrap items-center gap-1.5 text-xs font-mono-num text-slate-600 dark:text-slate-300 pt-1">
                      <span>{test.questions.length} Qs</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {test.isTimed ? `${test.timeLimitMinutes}m Timed` : 'Untimed'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Attempts: {comp.totalAttempts}/{MAX_TEST_ATTEMPTS}
                      </span>
                      {comp.totalAttempts > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="text-teal-600 dark:text-teal-400 font-semibold">
                            Best {comp.bestAccuracy}%
                          </span>
                        </>
                      )}
                    </div>
                  </button>

                  <div className="flex items-center gap-2 mt-3 pt-2.5 border-t border-slate-200/70 dark:border-slate-800">
                    {comp.canRetake ? (
                      <button
                        type="button"
                        onClick={() => startTestRun(test)}
                        className="min-h-[38px] flex-1 px-3 py-1.5 rounded-lg bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5"
                      >
                        {comp.totalAttempts === 0 ? (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>Start Test (1/{MAX_TEST_ATTEMPTS})</span>
                          </>
                        ) : (
                          <>
                            <RotateCcw className="w-3.5 h-3.5" />
                            <span>
                              Retake ({comp.totalAttempts + 1}/{MAX_TEST_ATTEMPTS})
                            </span>
                          </>
                        )}
                      </button>
                    ) : (
                      <span className="text-xs font-mono-num text-amber-600 dark:text-amber-400 font-medium py-1.5">
                        5/5 Attempts Completed
                      </span>
                    )}

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedTestId(test.id);
                        setMode('solutions');
                      }}
                      className="min-h-[38px] px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-xs font-semibold text-slate-800 dark:text-slate-200"
                    >
                      AI Teacher
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

        {/* Right: Selected Test Details, Attempt History Comparison & AI Teacher Solutions */}
        <section className="lg:col-span-8 space-y-6">
          {selectedTest && comparison ? (
            <>
              {/* Test Overview & Retake Controls Card */}
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400 font-mono-num">
                      <span>{selectedTest.questions.length} Questions</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {selectedTest.isTimed
                          ? `Timed (${selectedTest.timeLimitMinutes} mins)`
                          : 'Untimed Mode'}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span>
                        Attempts Used: {comparison.totalAttempts} / {MAX_TEST_ATTEMPTS} (
                        {getRemainingAttempts(selectedTest)} remaining)
                      </span>
                    </div>
                    <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
                      {selectedTest.title}
                    </h2>
                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                      Source Material: {selectedTest.sourceDocumentTitle}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-2">
                    {comparison.canRetake ? (
                      <>
                        <button
                          type="button"
                          onClick={() => startTestRun(selectedTest, false, false)}
                          className="min-h-[44px] px-4 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                        >
                          <Play className="w-4 h-4" />
                          <span>
                            {comparison.totalAttempts === 0
                              ? 'Start Test'
                              : `Retake Attempt #${comparison.totalAttempts + 1}`}
                          </span>
                        </button>
                        <button
                          type="button"
                          onClick={() => startTestRun(selectedTest, true, true)}
                          className="min-h-[44px] px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap"
                          title="Shuffle both questions and options for this attempt"
                        >
                          <Shuffle className="w-3.5 h-3.5" />
                          <span>Randomized Retake</span>
                        </button>
                      </>
                    ) : (
                      <div className="px-3.5 py-2 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 text-xs font-semibold text-amber-800 dark:text-amber-300">
                        Maximum 5 Attempts Reached — Review AI Teacher Solutions Below
                      </div>
                    )}
                  </div>
                </div>

                {/* Attempt History & Improvement Comparison Matrix */}
                {comparison.totalAttempts > 0 ? (
                  <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between">
                      <h3 className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                        <span>
                          Attempt History & Improvement Comparison ({comparison.totalAttempts}{' '}
                          / {MAX_TEST_ATTEMPTS} Attempts)
                        </span>
                      </h3>
                      <span className="text-xs font-mono-num font-semibold text-teal-600 dark:text-teal-400">
                        {comparison.accuracyImprovementDelta >= 0
                          ? `+${comparison.accuracyImprovementDelta}% vs Attempt #1`
                          : `${comparison.accuracyImprovementDelta}% vs Attempt #1`}
                      </span>
                    </div>

                    {/* 4 Comparison KPIs */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800">
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          First Attempt
                        </p>
                        <p className="text-lg font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
                          {comparison.firstScore}/{selectedTest.questions.length} (
                          {comparison.firstAccuracy}%)
                        </p>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800">
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Latest Attempt
                        </p>
                        <p className="text-lg font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
                          {comparison.latestScore}/{selectedTest.questions.length} (
                          {comparison.latestAccuracy}%)
                        </p>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800">
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Best Performance
                        </p>
                        <p className="text-lg font-bold font-mono-num text-teal-600 dark:text-teal-400 mt-0.5">
                          {comparison.bestScore}/{selectedTest.questions.length} (
                          {comparison.bestAccuracy}%)
                        </p>
                      </div>
                      <div className="p-3 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800">
                        <p className="text-xs text-slate-500 dark:text-slate-400">
                          Fastest Time
                        </p>
                        <p className="text-lg font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
                          {formatSeconds(comparison.fastestDurationSeconds)}
                        </p>
                      </div>
                    </div>

                    {/* Attempt Selector Tabs */}
                    <div className="space-y-2">
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Select any attempt below to inspect its answers alongside AI Teacher explanations:
                      </p>
                      <div className="flex flex-wrap gap-2">
                        {selectedTest.attempts.map((att) => {
                          const isCurrent = activeAttempt?.id === att.id;
                          return (
                            <button
                              key={att.id}
                              type="button"
                              onClick={() => setInspectedAttemptId(att.id)}
                              className={`min-h-[40px] px-3.5 py-2 rounded-xl text-xs font-mono-num font-semibold border transition-colors ${
                                isCurrent
                                  ? 'border-teal-600 bg-teal-600 text-white'
                                  : 'border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                              }`}
                            >
                              Attempt #{att.attemptNumber}: {att.score}/
                              {att.totalQuestions} ({att.accuracyPercent}%) ·{' '}
                              {formatSeconds(att.durationSeconds)}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-300">
                    You have not attempted this test yet. Click &ldquo;Start Test&rdquo; above to take Attempt #1 of 5, or scroll down to study with the AI Teacher.
                  </div>
                )}
              </div>

              {/* AI TEACHER SOLUTIONS & BILINGUAL HINDI/ENGLISH EXPLANATIONS */}
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                    <span>
                      AI Teacher — Complete Solutions & Simple Hindi Explanations (सरल हिंदी व्याख्या)
                    </span>
                  </h3>
                  {mode === 'solutions' && (
                    <button
                      type="button"
                      onClick={() => setMode('overview')}
                      className="text-xs font-semibold text-teal-600 dark:text-teal-400 flex items-center gap-1"
                    >
                      <ArrowLeft className="w-3.5 h-3.5" />
                      <span>Back to Overview</span>
                    </button>
                  )}
                </div>

                {selectedTest.questions.map((q, idx) => {
                  const userChosen = activeAttempt
                    ? activeAttempt.answers[q.id]
                    : null;
                  const isCorrect = userChosen === q.correctOption;
                  const doubtReply = doubtReplies[q.id];

                  return (
                    <article
                      key={q.id}
                      className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5"
                    >
                      {/* Question Header */}
                      <div className="space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono-num text-slate-500 dark:text-slate-400">
                          <span>
                            Question {idx + 1} · {q.topicTag} · {q.difficulty}
                          </span>
                          {activeAttempt && (
                            <span
                              className={`flex items-center gap-1 font-semibold ${
                                isCorrect
                                  ? 'text-emerald-600 dark:text-emerald-400'
                                  : 'text-rose-600 dark:text-rose-400'
                              }`}
                            >
                              {isCorrect ? (
                                <>
                                  <CheckCircle2 className="w-4 h-4" />
                                  <span>
                                    Attempt #{activeAttempt.attemptNumber}: Correct (Option{' '}
                                    {userChosen})
                                  </span>
                                </>
                              ) : (
                                <>
                                  <XCircle className="w-4 h-4" />
                                  <span>
                                    Attempt #{activeAttempt.attemptNumber}:{' '}
                                    {userChosen
                                      ? `Selected Option ${userChosen} (Incorrect)`
                                      : 'Unanswered'}
                                  </span>
                                </>
                              )}
                            </span>
                          )}
                        </div>

                        <h4 className="text-base font-bold text-slate-900 dark:text-white leading-relaxed">
                          {q.questionText}
                        </h4>
                        {q.questionHindi && (
                          <p className="text-sm text-slate-600 dark:text-slate-300 font-hindi">
                            {q.questionHindi}
                          </p>
                        )}
                      </div>

                      {/* Options with Correct / Selected Highlighting */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                        {(['A', 'B', 'C', 'D'] as OptionKey[]).map((key) => {
                          const isRight = key === q.correctOption;
                          const isPickedWrong =
                            userChosen === key && key !== q.correctOption;
                          return (
                            <div
                              key={key}
                              className={`p-3 rounded-xl border text-xs leading-relaxed flex items-start gap-2.5 ${
                                isRight
                                  ? 'border-emerald-500/60 bg-emerald-50/50 dark:bg-emerald-950/30 text-slate-900 dark:text-white font-semibold'
                                  : isPickedWrong
                                  ? 'border-rose-500/60 bg-rose-50/50 dark:bg-rose-950/30 text-slate-900 dark:text-white'
                                  : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400'
                              }`}
                            >
                              <span className="font-mono-num font-bold shrink-0">
                                {key}.
                              </span>
                              <div className="flex-1">
                                <span>{q.options[key]}</span>
                                {isRight && (
                                  <span className="block text-[11px] text-emerald-700 dark:text-emerald-400 mt-0.5">
                                    ✓ Correct Answer
                                  </span>
                                )}
                                {isPickedWrong && (
                                  <span className="block text-[11px] text-rose-700 dark:text-rose-400 mt-0.5">
                                    ✗ Your Choice in Attempt #{activeAttempt?.attemptNumber}
                                  </span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>

                      {/* AI Teacher Structured Breakdown */}
                      <div className="bg-slate-50 dark:bg-slate-950/80 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 sm:p-5 space-y-4">
                        {/* 1. Correct Answer & Detailed Solution */}
                        <div className="space-y-1">
                          <p className="text-xs font-bold text-teal-700 dark:text-teal-400">
                            1. Correct Answer ({q.correctOption}) & Detailed Solution
                          </p>
                          <p className="text-xs sm:text-sm text-slate-800 dark:text-slate-200 leading-relaxed">
                            {q.teacher.detailedSolution}
                          </p>
                        </div>

                        {/* 2. Simple Hindi Explanation */}
                        <div className="space-y-1 pt-3 border-t border-slate-200/70 dark:border-slate-800">
                          <p className="text-xs font-bold text-teal-700 dark:text-teal-400 font-hindi">
                            2. सरल हिंदी व्याख्या (Simple Hindi Explanation)
                          </p>
                          <p className="text-sm text-slate-800 dark:text-slate-200 font-hindi leading-relaxed">
                            {q.teacher.hindiExplanation}
                          </p>
                        </div>

                        {/* 3. Important Key Points */}
                        <div className="space-y-1.5 pt-3 border-t border-slate-200/70 dark:border-slate-800">
                          <p className="text-xs font-bold text-slate-900 dark:text-white">
                            3. Important Key Points
                          </p>
                          <ul className="list-disc list-inside space-y-1 text-xs text-slate-700 dark:text-slate-300">
                            {q.teacher.keyPoints.map((pt, i) => (
                              <li key={i}>{pt}</li>
                            ))}
                          </ul>
                        </div>

                        {/* 4. Related Exam-Relevant Information */}
                        <div className="space-y-1 pt-3 border-t border-slate-200/70 dark:border-slate-800">
                          <p className="text-xs font-bold text-slate-900 dark:text-white">
                            4. Related Exam-Relevant Information
                          </p>
                          <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                            {q.teacher.examRelevantInfo}
                          </p>
                        </div>

                        {/* 5. Explanation of Incorrect Options */}
                        {q.teacher.incorrectOptions.length > 0 && (
                          <div className="space-y-2 pt-3 border-t border-slate-200/70 dark:border-slate-800">
                            <p className="text-xs font-bold text-slate-900 dark:text-white">
                              5. Why Other Options Are Incorrect
                            </p>
                            <div className="space-y-2">
                              {q.teacher.incorrectOptions.map((inc) => (
                                <div
                                  key={inc.option}
                                  className="text-xs text-slate-700 dark:text-slate-300 bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200/70 dark:border-slate-800 space-y-0.5"
                                >
                                  <p className="font-semibold text-slate-900 dark:text-white">
                                    Option {inc.option}: {inc.reason}
                                  </p>
                                  <p className="text-slate-600 dark:text-slate-400 font-hindi">
                                    हिंदी: {inc.hindiReason}
                                  </p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* 6. Source-Based Answer vs Clearly Identified Additional Info */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-slate-200/70 dark:border-slate-800">
                          <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 space-y-1">
                            <p className="text-[11px] font-bold text-teal-700 dark:text-teal-400">
                              Source Excerpt (From Uploaded Material)
                            </p>
                            <p className="text-xs text-slate-700 dark:text-slate-300 italic leading-relaxed">
                              &ldquo;{q.teacher.sourceExcerpt}&rdquo;
                            </p>
                          </div>

                          <div className="p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200/70 dark:border-slate-800 space-y-1">
                            <p className="text-[11px] font-bold text-amber-700 dark:text-amber-400">
                              Additional Information (AI Teacher Context)
                            </p>
                            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                              {q.teacher.additionalInfo}
                            </p>
                          </div>
                        </div>

                        {/* Interactive Ask AI Teacher Follow-up */}
                        <div className="pt-3 border-t border-slate-200/70 dark:border-slate-800 space-y-2.5">
                          <div className="flex items-center gap-2">
                            <HelpCircle className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400 shrink-0" />
                            <label
                              htmlFor={`doubt-input-${q.id}`}
                              className="text-xs font-semibold text-slate-800 dark:text-slate-200"
                            >
                              Ask AI Teacher a follow-up doubt on Question {idx + 1}
                            </label>
                          </div>
                          <div className="flex gap-2">
                            <input
                              id={`doubt-input-${q.id}`}
                              type="text"
                              value={doubtInputs[q.id] || ''}
                              onChange={(e) =>
                                setDoubtInputs((prev) => ({
                                  ...prev,
                                  [q.id]: e.target.value,
                                }))
                              }
                              placeholder="Ask for a memory trick or deeper Hindi/English explanation..."
                              className="flex-1 min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                            />
                            <button
                              type="button"
                              disabled={doubtLoadingId === q.id}
                              onClick={() => handleAskTeacherDoubt(q)}
                              className="min-h-[40px] px-3.5 py-1.5 rounded-lg bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 text-xs font-semibold flex items-center gap-1.5 shrink-0"
                            >
                              <Send className="w-3.5 h-3.5" />
                              <span>
                                {doubtLoadingId === q.id ? 'Asking...' : 'Ask Teacher'}
                              </span>
                            </button>
                          </div>

                          {doubtReply && (
                            <div className="p-3 rounded-lg bg-teal-50/60 dark:bg-teal-950/30 border border-teal-500/30 space-y-1.5 text-xs">
                              <p className="text-slate-900 dark:text-slate-100">
                                <strong>AI Teacher (English):</strong> {doubtReply.englishReply}
                              </p>
                              <p className="text-slate-800 dark:text-slate-200 font-hindi">
                                <strong>एआई शिक्षक (हिंदी):</strong> {doubtReply.hindiReply}
                              </p>
                            </div>
                          )}
                        </div>
                      </div>
                    </article>
                  );
                })}
              </div>
            </>
          ) : (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center">
              <p className="text-base font-bold text-slate-900 dark:text-white">
                No AI Test Selected
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Generate a new test from your uploaded study documents to begin practicing.
              </p>
            </div>
          )}
        </section>
      </div>

      {/* Generate New AI Test Modal */}
      {showCreateModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="create-test-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5">
            <div className="flex items-center justify-between">
              <h2
                id="create-test-modal-title"
                className="text-lg font-bold text-slate-900 dark:text-white"
              >
                Generate AI MCQ Test from Uploaded Document
              </h2>
              <button
                type="button"
                onClick={() => setShowCreateModal(false)}
                className="min-h-[40px] px-2 text-xs text-slate-500"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleGenerateNewTest} className="space-y-4">
              <div>
                <label
                  htmlFor="gen-source-doc"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Select Uploaded Study Material
                </label>
                <select
                  id="gen-source-doc"
                  value={genDocId}
                  onChange={(e) => setGenDocId(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                >
                  {documents.map((doc) => (
                    <option key={doc.id} value={doc.id}>
                      {doc.title} ({doc.pages.filter((p) => p.selected).length} selected pages)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label
                  htmlFor="gen-test-title"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Custom Test Title
                </label>
                <input
                  id="gen-test-title"
                  type="text"
                  value={genTitle}
                  onChange={(e) => setGenTitle(e.target.value)}
                  placeholder="Leave blank to auto-title from document"
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label
                    htmlFor="gen-q-count"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Question Count
                  </label>
                  <input
                    id="gen-q-count"
                    type="number"
                    min="2"
                    max="10"
                    value={genQuestionCount}
                    onChange={(e) =>
                      setGenQuestionCount(parseInt(e.target.value, 10) || 4)
                    }
                    className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label
                    htmlFor="gen-timed-mode"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Timer Mode
                  </label>
                  <select
                    id="gen-timed-mode"
                    value={genIsTimed ? 'timed' : 'untimed'}
                    onChange={(e) => setGenIsTimed(e.target.value === 'timed')}
                    className="w-full min-h-[44px] px-3 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    <option value="timed">Timed Test</option>
                    <option value="untimed">Untimed Practice</option>
                  </select>
                </div>

                <div>
                  <label
                    htmlFor="gen-time-mins"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Duration (Mins)
                  </label>
                  <input
                    id="gen-time-mins"
                    type="number"
                    min="2"
                    max="180"
                    disabled={!genIsTimed}
                    value={genTimeMinutes}
                    onChange={(e) =>
                      setGenTimeMinutes(parseInt(e.target.value, 10) || 10)
                    }
                    className="w-full min-h-[44px] px-3 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white disabled:opacity-40"
                  />
                </div>
              </div>

              <div className="space-y-2 pt-1">
                <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={genRandomQuestions}
                    onChange={(e) => setGenRandomQuestions(e.target.checked)}
                  />
                  <span>Randomize question order on retakes</span>
                </label>
                <label className="flex items-center gap-2.5 text-xs text-slate-700 dark:text-slate-300">
                  <input
                    type="checkbox"
                    checked={genRandomOptions}
                    onChange={(e) => setGenRandomOptions(e.target.checked)}
                  />
                  <span>Randomize option order (A/B/C/D)</span>
                </label>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="min-h-[44px] px-4 py-2 text-xs font-medium rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isGeneratingTest}
                  className="min-h-[44px] px-5 py-2 text-xs font-semibold rounded-xl bg-teal-600 hover:bg-teal-700 text-white flex items-center gap-1.5"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>
                    {isGeneratingTest
                      ? 'Generating MCQs & Hindi Solutions...'
                      : 'Generate AI Test'}
                  </span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
