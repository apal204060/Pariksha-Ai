import React, { useEffect, useState } from 'react';
import {
  AppState,
  DailyTask,
  StudyDiagnostic,
  StudySessionLog,
  WeeklySlot,
} from '../types/study';
import {
  computeAutoMetrics,
  generateStudyRecommendations,
  getTodayIsoDate,
} from '../utils/studyEngine';
import { NavTab } from './TopBarAndNav';
import {
  Clock,
  CheckCircle2,
  Circle,
  Play,
  Pause,
  Plus,
  Trash2,
  SlidersHorizontal,
  ArrowRight,
  Calendar,
  Edit3,
  Check,
} from 'lucide-react';

interface HomePlannerViewProps {
  state: AppState;
  onUpdateDiagnostic: (diag: StudyDiagnostic) => void;
  onAddStudyLog: (log: StudySessionLog) => void;
  onToggleTask: (taskId: string) => void;
  onAddTask: (task: DailyTask) => void;
  onDeleteTask: (taskId: string) => void;
  onUpdateWeeklySlot: (slot: WeeklySlot) => void;
  onNavigateTab: (tab: NavTab) => void;
}

export const HomePlannerView: React.FC<HomePlannerViewProps> = ({
  state,
  onUpdateDiagnostic,
  onAddStudyLog,
  onToggleTask,
  onAddTask,
  onDeleteTask,
  onUpdateWeeklySlot,
  onNavigateTab,
}) => {
  const metrics = computeAutoMetrics(state);
  const recommendations = generateStudyRecommendations(state);
  const today = getTodayIsoDate();

  // Live Study Timer state
  const [timerRunning, setTimerRunning] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);
  const [manualHours, setManualHours] = useState('1.5');
  const [sessionNote, setSessionNote] = useState('');

  // New Daily Task state
  const [newTaskTitle, setNewTaskTitle] = useState('');
  const [newTaskMinutes, setNewTaskMinutes] = useState('30');
  const [newTaskPriority, setNewTaskPriority] = useState<'High' | 'Medium' | 'Low'>('High');

  // Diagnostic modal state
  const [showDiagnosticModal, setShowDiagnosticModal] = useState(false);
  const [diagDraft, setDiagDraft] = useState<StudyDiagnostic>(state.diagnostic);

  // Weekly schedule inline edit state
  const [editingSlotId, setEditingSlotId] = useState<string | null>(null);
  const [slotDraft, setSlotDraft] = useState<WeeklySlot | null>(null);

  useEffect(() => {
    setDiagDraft(state.diagnostic);
  }, [state.diagnostic]);

  useEffect(() => {
    if (!timerRunning) return;
    const interval = window.setInterval(() => {
      setTimerSeconds((prev) => prev + 1);
    }, 1000);
    return () => window.clearInterval(interval);
  }, [timerRunning]);

  const handleSaveTimerSession = () => {
    const loggedHours = Math.max(0.2, Number((timerSeconds / 3600).toFixed(2)));
    onAddStudyLog({
      id: `log_${Date.now()}`,
      date: today,
      hours: loggedHours,
      note: sessionNote.trim() || 'Timed live study session',
      createdAt: new Date().toISOString(),
    });
    setTimerRunning(false);
    setTimerSeconds(0);
    setSessionNote('');
  };

  const handleManualLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = parseFloat(manualHours);
    if (isNaN(parsed) || parsed <= 0 || parsed > 18) return;
    onAddStudyLog({
      id: `log_${Date.now()}`,
      date: today,
      hours: Number(parsed.toFixed(1)),
      note: sessionNote.trim() || 'Focused exam study block',
      createdAt: new Date().toISOString(),
    });
    setSessionNote('');
  };

  const handleAddTaskSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskTitle.trim()) return;
    const mins = Math.max(5, parseInt(newTaskMinutes, 10) || 30);
    onAddTask({
      id: `task_${Date.now()}`,
      title: newTaskTitle.trim(),
      date: today,
      targetMinutes: mins,
      completed: false,
      priority: newTaskPriority,
    });
    setNewTaskTitle('');
  };

  const handleDiagnosticSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!diagDraft.targetExamName.trim()) return;
    onUpdateDiagnostic({
      ...diagDraft,
      completed: true,
      updatedAt: new Date().toISOString(),
    });
    setShowDiagnosticModal(false);
  };

  const dailyGoalPercent = Math.min(
    100,
    Math.round(
      (metrics.daily_study_hours / Math.max(1, state.diagnostic.dailyHoursTarget)) * 100
    )
  );

  const completedTasksCount = state.dailyTasks.filter((t) => t.completed).length;

  const formatTimer = (secs: number) => {
    const hrs = Math.floor(secs / 3600);
    const mins = Math.floor((secs % 3600) / 60);
    const s = secs % 60;
    return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(
      s
    ).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-8">
      {/* Top Hero & Daily Target Anchor */}
      <section className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
          <div className="lg:col-span-7 flex flex-col justify-between space-y-4">
            <div className="space-y-2">
              <div className="flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
                <span>{state.diagnostic.targetExamName}</span>
                <span aria-hidden="true">·</span>
                <span>Level: {state.diagnostic.currentLevel}</span>
                <span aria-hidden="true">·</span>
                <span>Focus: {state.diagnostic.focusPriority}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight text-balance">
                Daily Study Planner & Preparation Diagnostic
              </h1>
              <p className="text-sm text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed">
                Track today’s study hours, execute prioritized preparation tasks, and follow adaptive recommendations driven by your actual MCQ test attempts.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                type="button"
                onClick={() => onNavigateTab('tests')}
                className="min-h-[44px] px-5 py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-sm font-semibold rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <span>Start or Retake AI Test</span>
                <ArrowRight className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setShowDiagnosticModal(true)}
                className="min-h-[44px] px-4 py-2.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 text-sm font-medium rounded-xl transition-colors flex items-center gap-2 whitespace-nowrap"
              >
                <SlidersHorizontal className="w-4 h-4" />
                <span>Calibrate Diagnostic Targets</span>
              </button>
            </div>
          </div>

          {/* Right Column: Daily Progress Ring + Quick Study Logger */}
          <div className="lg:col-span-5 bg-slate-50 dark:bg-slate-950/70 border border-slate-200/80 dark:border-slate-800 rounded-xl p-4 sm:p-5 flex flex-col justify-between space-y-4">
            <div className="flex items-center justify-between gap-4">
              <div>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Today’s Study Hours ({today})
                </p>
                <div className="flex items-baseline gap-2 mt-1">
                  <span className="text-3xl font-bold font-mono-num text-slate-900 dark:text-white">
                    {metrics.daily_study_hours}h
                  </span>
                  <span className="text-sm text-slate-500 dark:text-slate-400 font-mono-num">
                    / {state.diagnostic.dailyHoursTarget}h target ({dailyGoalPercent}%)
                  </span>
                </div>
              </div>

              {/* SVG Progress Ring */}
              <div className="relative w-16 h-16 shrink-0">
                <svg className="w-16 h-16 -rotate-90" viewBox="0 0 64 64">
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="6"
                    className="text-slate-200 dark:text-slate-800"
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="6"
                    strokeDasharray={2 * Math.PI * 26}
                    strokeDashoffset={
                      2 * Math.PI * 26 * (1 - Math.min(1, dailyGoalPercent / 100))
                    }
                    strokeLinecap="round"
                    className="text-teal-600 dark:text-teal-400 transition-all duration-300"
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center text-xs font-bold font-mono-num text-slate-900 dark:text-white">
                  {dailyGoalPercent}%
                </div>
              </div>
            </div>

            {/* Live Study Timer & Manual Logger */}
            <div className="pt-2 border-t border-slate-200 dark:border-slate-800 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-teal-600 dark:text-teal-400" />
                  <span className="text-sm font-mono-num font-semibold text-slate-900 dark:text-white">
                    {formatTimer(timerSeconds)}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => setTimerRunning((r) => !r)}
                    className="min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-semibold bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900 flex items-center gap-1.5 whitespace-nowrap"
                  >
                    {timerRunning ? (
                      <>
                        <Pause className="w-3.5 h-3.5" />
                        <span>Pause Timer</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5" />
                        <span>Start Timer</span>
                      </>
                    )}
                  </button>
                  {timerSeconds > 0 && (
                    <button
                      type="button"
                      onClick={handleSaveTimerSession}
                      className="min-h-[40px] px-3 py-1.5 rounded-lg text-xs font-semibold bg-teal-600 text-white hover:bg-teal-700 whitespace-nowrap"
                    >
                      Save Timer
                    </button>
                  )}
                </div>
              </div>

              <form onSubmit={handleManualLogSubmit} className="flex flex-wrap sm:flex-nowrap items-center gap-2">
                <label htmlFor="manual-hours-input" className="sr-only">
                  Study Hours to Log
                </label>
                <input
                  id="manual-hours-input"
                  type="number"
                  step="0.5"
                  min="0.5"
                  max="16"
                  value={manualHours}
                  onChange={(e) => setManualHours(e.target.value)}
                  className="w-20 min-h-[40px] px-2.5 py-1.5 text-xs font-mono-num rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  placeholder="Hrs"
                />
                <label htmlFor="session-note-input" className="sr-only">
                  Study Session Note
                </label>
                <input
                  id="session-note-input"
                  type="text"
                  value={sessionNote}
                  onChange={(e) => setSessionNote(e.target.value)}
                  className="flex-1 min-w-[140px] min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  placeholder="Topic studied (e.g., Writs & Optics)"
                />
                <button
                  type="submit"
                  className="min-h-[40px] px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-slate-200 hover:bg-slate-300 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-white whitespace-nowrap shrink-0"
                >
                  + Log Hours
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Full-Width 4-Column KPI Summary Row Below Hero Split */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6 pt-6 border-t border-slate-200 dark:border-slate-800">
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">7-Day Study Volume</p>
            <p className="text-xl font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
              {metrics.weekly_study_hours} hrs
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Tests & Attempts</p>
            <p className="text-xl font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
              {metrics.tests_completed} tests · {metrics.total_attempts} runs
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Average Test Accuracy</p>
            <p className="text-xl font-bold font-mono-num text-teal-600 dark:text-teal-400 mt-0.5">
              {metrics.average_accuracy}%
            </p>
          </div>
          <div>
            <p className="text-xs text-slate-500 dark:text-slate-400">Today’s Tasks Done</p>
            <p className="text-xl font-bold font-mono-num text-slate-900 dark:text-white mt-0.5">
              {completedTasksCount} / {state.dailyTasks.length}
            </p>
          </div>
        </div>
      </section>

      {/* Performance-Based Study Recommendations */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">
            Performance-Based Study Recommendations
          </h2>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Updated from your test attempts & hours
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {recommendations.map((rec) => (
            <div
              key={rec.id}
              className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <p className="text-xs font-medium text-teal-700 dark:text-teal-400">
                  {rec.severity === 'focus'
                    ? 'Priority Improvement Area'
                    : rec.severity === 'positive'
                    ? 'On Track'
                    : 'Daily Action'}
                </p>
                <h3 className="text-base font-bold text-slate-900 dark:text-white">
                  {rec.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {rec.reason}
                </p>
              </div>
              <button
                type="button"
                onClick={() => onNavigateTab(rec.targetTab)}
                className="min-h-[40px] w-full px-4 py-2 text-xs font-semibold rounded-xl bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-900 dark:text-white flex items-center justify-between transition-colors"
              >
                <span>{rec.actionLabel}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* Two-Column Split: Daily Task Checklist + Editable Weekly Study Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Daily Task Checklist */}
        <section className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                Daily Study Tasks
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Check off completed study blocks or add custom daily targets
              </p>
            </div>
            <span className="text-xs font-mono-num text-slate-500 dark:text-slate-400">
              {completedTasksCount}/{state.dailyTasks.length} done
            </span>
          </div>

          <form onSubmit={handleAddTaskSubmit} className="space-y-2.5">
            <div className="flex flex-col sm:flex-row gap-2">
              <label htmlFor="new-task-title" className="sr-only">
                New Study Task Title
              </label>
              <input
                id="new-task-title"
                type="text"
                value={newTaskTitle}
                onChange={(e) => setNewTaskTitle(e.target.value)}
                placeholder="Add a daily study task (e.g. Solve 25 Optics MCQs)..."
                className="flex-1 min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
              />
              <div className="flex items-center gap-2">
                <label htmlFor="new-task-mins" className="sr-only">
                  Target Minutes
                </label>
                <input
                  id="new-task-mins"
                  type="number"
                  min="5"
                  max="300"
                  value={newTaskMinutes}
                  onChange={(e) => setNewTaskMinutes(e.target.value)}
                  className="w-20 min-h-[44px] px-2.5 py-2 text-xs font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  title="Target minutes"
                />
                <label htmlFor="new-task-priority" className="sr-only">
                  Task Priority
                </label>
                <select
                  id="new-task-priority"
                  value={newTaskPriority}
                  onChange={(e) =>
                    setNewTaskPriority(e.target.value as 'High' | 'Medium' | 'Low')
                  }
                  className="min-h-[44px] px-2.5 py-2 text-xs rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                >
                  <option value="High">High</option>
                  <option value="Medium">Medium</option>
                  <option value="Low">Low</option>
                </select>
                <button
                  type="submit"
                  aria-label="Add Daily Task"
                  className="min-h-[44px] px-4 py-2 bg-teal-600 hover:bg-teal-700 text-white text-xs font-semibold rounded-xl flex items-center gap-1.5 whitespace-nowrap shrink-0"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add</span>
                </button>
              </div>
            </div>
          </form>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {state.dailyTasks.length === 0 ? (
              <p className="py-6 text-center text-sm text-slate-500 dark:text-slate-400">
                No tasks scheduled for today. Add your first study target above.
              </p>
            ) : (
              state.dailyTasks.map((task) => (
                <div
                  key={task.id}
                  className="py-3 flex items-center justify-between gap-3"
                >
                  <button
                    type="button"
                    aria-label={`Toggle task: ${task.title}`}
                    onClick={() => onToggleTask(task.id)}
                    className="flex items-start gap-3 text-left flex-1 min-h-[44px] py-1"
                  >
                    {task.completed ? (
                      <CheckCircle2 className="w-5 h-5 text-teal-600 dark:text-teal-400 shrink-0 mt-0.5" />
                    ) : (
                      <Circle className="w-5 h-5 text-slate-400 shrink-0 mt-0.5" />
                    )}
                    <div>
                      <p
                        className={`text-sm font-medium ${
                          task.completed
                            ? 'line-through text-slate-400 dark:text-slate-500'
                            : 'text-slate-900 dark:text-slate-100'
                        }`}
                      >
                        {task.title}
                      </p>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 font-mono-num">
                        {task.targetMinutes} mins · {task.priority} Priority
                      </p>
                    </div>
                  </button>
                  <button
                    type="button"
                    aria-label={`Delete task ${task.title}`}
                    onClick={() => onDeleteTask(task.id)}
                    className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-rose-600 dark:hover:text-rose-400 rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </section>

        {/* Editable Weekly Schedule */}
        <section className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Calendar className="w-5 h-5 text-teal-600 dark:text-teal-400" />
                <span>Editable Weekly Schedule</span>
              </h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                Customize your Monday–Sunday study slots and daily hour allocations
              </p>
            </div>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {state.weeklySchedule.map((slot) => {
              const isEditing = editingSlotId === slot.id && slotDraft;
              return (
                <div key={slot.id} className="py-3">
                  {isEditing ? (
                    <div className="space-y-2.5 bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-teal-600 dark:text-teal-400">
                          Editing {slot.day}
                        </span>
                        <label className="flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                          <input
                            type="checkbox"
                            checked={slotDraft.active}
                            onChange={(e) =>
                              setSlotDraft({ ...slotDraft, active: e.target.checked })
                            }
                          />
                          <span>Active Day</span>
                        </label>
                      </div>
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                        <input
                          type="text"
                          value={slotDraft.timeRange}
                          onChange={(e) =>
                            setSlotDraft({ ...slotDraft, timeRange: e.target.value })
                          }
                          placeholder="Time range"
                          className="sm:col-span-2 min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                        />
                        <input
                          type="number"
                          step="0.5"
                          min="0"
                          max="16"
                          value={slotDraft.targetHours}
                          onChange={(e) =>
                            setSlotDraft({
                              ...slotDraft,
                              targetHours: parseFloat(e.target.value) || 0,
                            })
                          }
                          placeholder="Hours"
                          className="min-h-[40px] px-3 py-1.5 text-xs font-mono-num rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                        />
                      </div>
                      <input
                        type="text"
                        value={slotDraft.activity}
                        onChange={(e) =>
                          setSlotDraft({ ...slotDraft, activity: e.target.value })
                        }
                        placeholder="Planned study activity"
                        className="w-full min-h-[40px] px-3 py-1.5 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                      />
                      <div className="flex justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingSlotId(null);
                            setSlotDraft(null);
                          }}
                          className="min-h-[38px] px-3 py-1 text-xs rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-800 dark:text-slate-200"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            onUpdateWeeklySlot(slotDraft);
                            setEditingSlotId(null);
                            setSlotDraft(null);
                          }}
                          className="min-h-[38px] px-3 py-1 text-xs font-semibold rounded-lg bg-teal-600 text-white flex items-center gap-1"
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>Save Slot</span>
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <span className="w-10 text-xs font-bold font-mono-num text-teal-700 dark:text-teal-400 pt-0.5">
                          {slot.day}
                        </span>
                        <div>
                          <p
                            className={`text-sm font-medium ${
                              slot.active
                                ? 'text-slate-900 dark:text-slate-100'
                                : 'text-slate-400 line-through'
                            }`}
                          >
                            {slot.activity}
                          </p>
                          <p className="text-xs text-slate-500 dark:text-slate-400 font-mono-num mt-0.5">
                            {slot.timeRange} · {slot.targetHours}h target
                          </p>
                        </div>
                      </div>
                      <button
                        type="button"
                        aria-label={`Edit ${slot.day} schedule`}
                        onClick={() => {
                          setEditingSlotId(slot.id);
                          setSlotDraft({ ...slot });
                        }}
                        className="min-h-[44px] min-w-[44px] flex items-center justify-center text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-lg"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      </div>

      {/* Diagnostic Calibration Modal */}
      {showDiagnosticModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="diagnostic-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
        >
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 space-y-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2
                id="diagnostic-modal-title"
                className="text-lg font-bold text-slate-900 dark:text-white"
              >
                Initial Preparation Diagnostic & Daily Targets
              </h2>
              <button
                type="button"
                onClick={() => setShowDiagnosticModal(false)}
                className="min-h-[40px] px-3 text-xs font-medium text-slate-500 hover:text-slate-900 dark:hover:text-white"
              >
                Close
              </button>
            </div>

            <form onSubmit={handleDiagnosticSave} className="space-y-4">
              <div>
                <label
                  htmlFor="diag-exam-name"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Target Exam Name
                </label>
                <input
                  id="diag-exam-name"
                  type="text"
                  required
                  value={diagDraft.targetExamName}
                  onChange={(e) =>
                    setDiagDraft({ ...diagDraft, targetExamName: e.target.value })
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label
                    htmlFor="diag-exam-date"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Target Exam Date
                  </label>
                  <input
                    id="diag-exam-date"
                    type="date"
                    value={diagDraft.examDate}
                    onChange={(e) =>
                      setDiagDraft({ ...diagDraft, examDate: e.target.value })
                    }
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label
                    htmlFor="diag-level"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Current Preparation Stage
                  </label>
                  <select
                    id="diag-level"
                    value={diagDraft.currentLevel}
                    onChange={(e) =>
                      setDiagDraft({
                        ...diagDraft,
                        currentLevel: e.target.value as StudyDiagnostic['currentLevel'],
                      })
                    }
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  >
                    <option value="Beginner">Beginner (Building Foundation)</option>
                    <option value="Intermediate">Intermediate (Concept + Practice)</option>
                    <option value="Advanced">Advanced (Test Mastery & Speed)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label
                    htmlFor="diag-hours"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Daily Study Hours Goal
                  </label>
                  <input
                    id="diag-hours"
                    type="number"
                    step="0.5"
                    min="1"
                    max="16"
                    value={diagDraft.dailyHoursTarget}
                    onChange={(e) =>
                      setDiagDraft({
                        ...diagDraft,
                        dailyHoursTarget: parseFloat(e.target.value) || 4,
                      })
                    }
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label
                    htmlFor="diag-questions"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Daily MCQs Goal
                  </label>
                  <input
                    id="diag-questions"
                    type="number"
                    min="5"
                    max="300"
                    value={diagDraft.dailyQuestionsTarget}
                    onChange={(e) =>
                      setDiagDraft({
                        ...diagDraft,
                        dailyQuestionsTarget: parseInt(e.target.value, 10) || 30,
                      })
                    }
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
                <div>
                  <label
                    htmlFor="diag-tests"
                    className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                  >
                    Weekly Tests Goal
                  </label>
                  <input
                    id="diag-tests"
                    type="number"
                    min="1"
                    max="30"
                    value={diagDraft.weeklyTestsTarget}
                    onChange={(e) =>
                      setDiagDraft({
                        ...diagDraft,
                        weeklyTestsTarget: parseInt(e.target.value, 10) || 4,
                      })
                    }
                    className="w-full min-h-[44px] px-3.5 py-2 text-sm font-mono-num rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                  />
                </div>
              </div>

              <div>
                <label
                  htmlFor="diag-priority"
                  className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1"
                >
                  Primary Diagnostic Focus
                </label>
                <select
                  id="diag-priority"
                  value={diagDraft.focusPriority}
                  onChange={(e) =>
                    setDiagDraft({
                      ...diagDraft,
                      focusPriority: e.target.value as StudyDiagnostic['focusPriority'],
                    })
                  }
                  className="w-full min-h-[44px] px-3.5 py-2 text-sm rounded-xl border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-white"
                >
                  <option value="Accuracy & Concepts">Accuracy & Concepts</option>
                  <option value="Speed & Time Management">Speed & Time Management</option>
                  <option value="Practice Volume">Practice Volume</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowDiagnosticModal(false)}
                  className="min-h-[44px] px-4 py-2 text-xs font-medium rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-5 py-2 text-xs font-semibold rounded-xl bg-teal-600 hover:bg-teal-700 text-white"
                >
                  Save Diagnostic Targets
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
