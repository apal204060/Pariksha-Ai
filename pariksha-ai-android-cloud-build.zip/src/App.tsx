import { useCallback, useEffect, useState } from 'react';
import { createInitialAppState } from './data/initialState';
import {
  AppState,
  DailyTask,
  MilestoneItem,
  StudyDiagnostic,
  StudyDocument,
  StudySessionLog,
  SyncStatus,
  TestAttempt,
  TestItem,
  ThemeMode,
  TrackerCategory,
  UserProfile,
  WeeklySlot,
} from './types/study';
import { syncTrackerCategoriesWithActivity } from './utils/studyEngine';
import { useOnlineStatus } from './hooks/usePWAInstall';
import { NavTab, TopBarAndNav } from './components/TopBarAndNav';
import { HomePlannerView } from './components/HomePlannerView';
import { UploadOcrView } from './components/UploadOcrView';
import { TestSystemView } from './components/TestSystemView';
import { CustomTrackerView } from './components/CustomTrackerView';
import { ProfileSyncView } from './components/ProfileSyncView';

const STORAGE_KEY = 'pariksha_ai_state_v1';

function loadPersistedState(): AppState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as AppState;
      if (parsed && Array.isArray(parsed.documents) && Array.isArray(parsed.tests)) {
        parsed.trackerCategories = syncTrackerCategoriesWithActivity(
          parsed.trackerCategories || [],
          parsed
        );
        return parsed;
      }
    }
  } catch (err) {
    console.error('Error loading persisted state:', err);
  }
  return createInitialAppState();
}

export default function App() {
  const [state, setState] = useState<AppState>(() => loadPersistedState());
  const [activeTab, setActiveTab] = useState<NavTab>('home');
  const [preselectedDocForTest, setPreselectedDocForTest] = useState<string | null>(
    null
  );
  const isOnline = useOnlineStatus();
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('Synced');

  // Persist to localStorage & keep custom tracker synced with actual activity
  const updateAppState = useCallback((updater: (prev: AppState) => AppState) => {
    setState((prev) => {
      const next = updater(prev);
      const syncedTrackers = syncTrackerCategoriesWithActivity(
        next.trackerCategories,
        next
      );
      const finalState: AppState = {
        ...next,
        trackerCategories: syncedTrackers,
      };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(finalState));
      } catch (err) {
        console.error('Failed to save to localStorage:', err);
      }
      return finalState;
    });
  }, []);

  // Apply Day/Night/System theme to <html>
  useEffect(() => {
    const root = document.documentElement;
    const applyTheme = (mode: ThemeMode) => {
      if (mode === 'dark') {
        root.classList.add('dark');
      } else if (mode === 'light') {
        root.classList.remove('dark');
      } else {
        const prefersDark = window.matchMedia(
          '(prefers-color-scheme: dark)'
        ).matches;
        if (prefersDark) {
          root.classList.add('dark');
        } else {
          root.classList.remove('dark');
        }
      }
    };

    applyTheme(state.theme);

    if (state.theme === 'system') {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme('system');
      media.addEventListener('change', listener);
      return () => media.removeEventListener('change', listener);
    }
  }, [state.theme]);

  // Update sync status when online/offline changes
  useEffect(() => {
    if (!isOnline) {
      setSyncStatus('Offline');
    } else if (syncStatus === 'Offline') {
      setSyncStatus('Synced');
    }
  }, [isOnline, syncStatus]);

  // Server Cloud Synchronization
  const triggerServerSync = useCallback(async () => {
    if (!navigator.onLine) {
      setSyncStatus('Offline');
      return;
    }
    setSyncStatus('Syncing');
    try {
      const res = await fetch(
        `/api/sync/${encodeURIComponent(state.profile.uid)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ state }),
        }
      );
      if (!res.ok) {
        throw new Error(`Sync failed with status ${res.status}`);
      }
      const data = await res.json();
      updateAppState((prev) => ({
        ...prev,
        profile: {
          ...prev.profile,
          lastSyncedAt: data.syncedAt || new Date().toISOString(),
        },
      }));
      setSyncStatus('Synced');
    } catch {
      setSyncStatus('Failed');
    }
  }, [state, updateAppState]);

  // Action Handlers
  const handleUpdateDiagnostic = (diagnostic: StudyDiagnostic) => {
    updateAppState((prev) => ({
      ...prev,
      diagnostic,
      trackerCategories: prev.trackerCategories.map((c) =>
        c.autoMetric === 'daily_study_hours'
          ? { ...c, targetValue: diagnostic.dailyHoursTarget }
          : c
      ),
    }));
  };

  const handleAddStudyLog = (log: StudySessionLog) => {
    updateAppState((prev) => ({
      ...prev,
      studyLogs: [log, ...prev.studyLogs],
    }));
  };

  const handleToggleTask = (taskId: string) => {
    updateAppState((prev) => ({
      ...prev,
      dailyTasks: prev.dailyTasks.map((t) =>
        t.id === taskId ? { ...t, completed: !t.completed } : t
      ),
    }));
  };

  const handleAddTask = (task: DailyTask) => {
    updateAppState((prev) => ({
      ...prev,
      dailyTasks: [task, ...prev.dailyTasks],
    }));
  };

  const handleDeleteTask = (taskId: string) => {
    updateAppState((prev) => ({
      ...prev,
      dailyTasks: prev.dailyTasks.filter((t) => t.id !== taskId),
    }));
  };

  const handleUpdateWeeklySlot = (slot: WeeklySlot) => {
    updateAppState((prev) => ({
      ...prev,
      weeklySchedule: prev.weeklySchedule.map((s) =>
        s.id === slot.id ? slot : s
      ),
    }));
  };

  const handleSaveDocument = (doc: StudyDocument) => {
    updateAppState((prev) => {
      const exists = prev.documents.some((d) => d.id === doc.id);
      const nextDocs = exists
        ? prev.documents.map((d) => (d.id === doc.id ? doc : d))
        : [doc, ...prev.documents];
      return {
        ...prev,
        documents: nextDocs,
      };
    });
  };

  const handleDeleteDocument = (docId: string) => {
    updateAppState((prev) => ({
      ...prev,
      documents: prev.documents.filter((d) => d.id !== docId),
    }));
  };

  const handleGenerateTestFromDoc = (docId: string) => {
    setPreselectedDocForTest(docId);
    setActiveTab('tests');
  };

  const handleCreateTest = (newTest: TestItem) => {
    updateAppState((prev) => ({
      ...prev,
      tests: [newTest, ...prev.tests],
    }));
  };

  const handleRecordTestAttempt = (testId: string, attempt: TestAttempt) => {
    updateAppState((prev) => ({
      ...prev,
      tests: prev.tests.map((t) =>
        t.id === testId
          ? {
              ...t,
              attempts: [...t.attempts, attempt].slice(0, 5),
            }
          : t
      ),
    }));
  };

  const handleUpdateTrackerCategories = (categories: TrackerCategory[]) => {
    updateAppState((prev) => ({
      ...prev,
      trackerCategories: categories,
    }));
  };

  const handleUpdateMilestones = (milestones: MilestoneItem[]) => {
    updateAppState((prev) => ({
      ...prev,
      milestones,
    }));
  };

  const handleUpdateStrongWeakAreas = (
    customStrongAreas: string[],
    customWeakAreas: string[]
  ) => {
    updateAppState((prev) => ({
      ...prev,
      customStrongAreas,
      customWeakAreas,
    }));
  };

  const handleUpdateTheme = (theme: ThemeMode) => {
    updateAppState((prev) => ({
      ...prev,
      theme,
    }));
  };

  const handleUpdateProfile = (profile: UserProfile) => {
    updateAppState((prev) => ({
      ...prev,
      profile,
    }));
  };

  const handleRestoreFullState = (restored: AppState) => {
    updateAppState(() => restored);
    setSyncStatus('Synced');
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 pb-24">
      <TopBarAndNav
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        isOnline={isOnline}
      />

      <main className="flex-1 w-full max-w-7xl mx-auto px-4 sm:px-6 pt-6">
        {activeTab === 'home' && (
          <HomePlannerView
            state={state}
            onUpdateDiagnostic={handleUpdateDiagnostic}
            onAddStudyLog={handleAddStudyLog}
            onToggleTask={handleToggleTask}
            onAddTask={handleAddTask}
            onDeleteTask={handleDeleteTask}
            onUpdateWeeklySlot={handleUpdateWeeklySlot}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'upload' && (
          <UploadOcrView
            documents={state.documents}
            onSaveDocument={handleSaveDocument}
            onDeleteDocument={handleDeleteDocument}
            onGenerateTestFromDoc={handleGenerateTestFromDoc}
          />
        )}

        {activeTab === 'tests' && (
          <TestSystemView
            tests={state.tests}
            documents={state.documents}
            preselectedDocId={preselectedDocForTest}
            onClearPreselectedDoc={() => setPreselectedDocForTest(null)}
            onCreateTest={handleCreateTest}
            onRecordTestAttempt={handleRecordTestAttempt}
          />
        )}

        {activeTab === 'tracker' && (
          <CustomTrackerView
            state={state}
            onUpdateCategories={handleUpdateTrackerCategories}
            onUpdateMilestones={handleUpdateMilestones}
            onUpdateStrongWeakAreas={handleUpdateStrongWeakAreas}
          />
        )}

        {activeTab === 'profile' && (
          <ProfileSyncView
            state={state}
            syncStatus={syncStatus}
            onUpdateTheme={handleUpdateTheme}
            onUpdateProfile={handleUpdateProfile}
            onRestoreFullState={handleRestoreFullState}
            onTriggerServerSync={triggerServerSync}
          />
        )}
      </main>
    </div>
  );
}
